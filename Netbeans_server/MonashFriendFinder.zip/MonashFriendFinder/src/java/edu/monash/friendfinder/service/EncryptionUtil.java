package edu.monash.friendfinder.service;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 05/05/2017
 * Time: 11:06
 * Place: SEU
 */


// import org.apache.commons.codec.binary.Base64;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

/**
 * @author JavaDigest
 *
 */
public class EncryptionUtil {

//    /**
//     * String to hold name of the encryption algorithm.
//     */
//    public static final String ALGORITHM = "RSA";
//
//    /**
//     * String to hold name of the encryption padding.
//     */
//    public static final String PADDING = "RSA/NONE/NoPadding";
//
//    /**
//     * String to hold name of the security provider.
//     */
//    public static final String PROVIDER = "BC";
//    
//    /* 密钥内容 base64 code */
//    public static final  String PUCLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCfRTdcPIH10gT9f31rQuIInLwe"
//            + "\r" + "7fl2dtEJ93gTmjE9c2H+kLVENWgECiJVQ5sonQNfwToMKdO0b3Olf4pgBKeLThra" + "\r"
//            + "z/L3nYJYlbqjHC3jTjUnZc0luumpXGsox62+PuSGBlfb8zJO6hix4GV/vhyQVCpG" + "\r"
//            + "9aYqgE7zyTRZYX9byQIDAQAB" + "\r";
//    public static final  String PRIVATE_KEY = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAJ9FN1w8gfXSBP1/"
//            + "\r" + "fWtC4gicvB7t+XZ20Qn3eBOaMT1zYf6QtUQ1aAQKIlVDmyidA1/BOgwp07Rvc6V/" + "\r"
//            + "imAEp4tOGtrP8vedgliVuqMcLeNONSdlzSW66alcayjHrb4+5IYGV9vzMk7qGLHg" + "\r"
//            + "ZX++HJBUKkb1piqATvPJNFlhf1vJAgMBAAECgYA736xhG0oL3EkN9yhx8zG/5RP/" + "\r"
//            + "WJzoQOByq7pTPCr4m/Ch30qVerJAmoKvpPumN+h1zdEBk5PHiAJkm96sG/PTndEf" + "\r"
//            + "kZrAJ2hwSBqptcABYk6ED70gRTQ1S53tyQXIOSjRBcugY/21qeswS3nMyq3xDEPK" + "\r"
//            + "XpdyKPeaTyuK86AEkQJBAM1M7p1lfzEKjNw17SDMLnca/8pBcA0EEcyvtaQpRvaL" + "\r"
//            + "n61eQQnnPdpvHamkRBcOvgCAkfwa1uboru0QdXii/gUCQQDGmkP+KJPX9JVCrbRt" + "\r"
//            + "7wKyIemyNM+J6y1ZBZ2bVCf9jacCQaSkIWnIR1S9UM+1CFE30So2CA0CfCDmQy+y" + "\r"
//            + "7A31AkB8cGFB7j+GTkrLP7SX6KtRboAU7E0q1oijdO24r3xf/Imw4Cy0AAIx4KAu" + "\r"
//            + "L29GOp1YWJYkJXCVTfyZnRxXHxSxAkEAvO0zkSv4uI8rDmtAIPQllF8+eRBT/deD" + "\r"
//            + "JBR7ga/k+wctwK/Bd4Fxp9xzeETP0l8/I+IOTagK+Dos8d8oGQUFoQJBAI4Nwpfo" + "\r"
//            + "MFaLJXGY9ok45wXrcqkJgM+SN6i8hQeujXESVHYatAIL/1DgLi+u46EFD69fw0w+" + "\r" + "c7o0HLlMsYPAzJw="
//            + "\r";
//
//    /**
//     * String to hold the name of the private key file.
//     */
//    // public static final String PRIVATE_KEY_FILE = "e:/defonds/work/20150116/private.key";
//
//    /**
//     * String to hold name of the public key file.
//     */
//    // public static final String PUBLIC_KEY_FILE = "e:/defonds/work/20150116/public.key";
//
//    /**
//     * Generate key which contains a pair of private and public key using 1024
//     * bytes. Store the set of keys in Prvate.key and Public.key files.
//     *
//     * @throws NoSuchAlgorithmException
//     * @throws IOException
//     * @throws FileNotFoundException
//     */
////    public static void generateKey() {
////        try {
////
////            Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
////            final KeyPairGenerator keyGen = KeyPairGenerator.getInstance(
////                    ALGORITHM, PROVIDER);
////            keyGen.initialize(256);
////            final KeyPair key = keyGen.generateKeyPair();
////
////            File privateKeyFile = new File(PRIVATE_KEY_FILE);
////            File publicKeyFile = new File(PUBLIC_KEY_FILE);
////
////            // Create files to store public and private key
////            if (privateKeyFile.getParentFile() != null) {
////                privateKeyFile.getParentFile().mkdirs();
////            }
////            privateKeyFile.createNewFile();
////
////            if (publicKeyFile.getParentFile() != null) {
////                publicKeyFile.getParentFile().mkdirs();
////            }
////            publicKeyFile.createNewFile();
////
////            // Saving the Public key in a file
////            ObjectOutputStream publicKeyOS = new ObjectOutputStream(
////                    new FileOutputStream(publicKeyFile));
////            publicKeyOS.writeObject(key.getPublic());
////            publicKeyOS.close();
////
////            // Saving the Private key in a file
////            ObjectOutputStream privateKeyOS = new ObjectOutputStream(
////                    new FileOutputStream(privateKeyFile));
////            privateKeyOS.writeObject(key.getPrivate());
////            privateKeyOS.close();
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////
////    }
//
//    /**
//     * The method checks if the pair of public and private key has been
//     * generated.
//     *
//     * @return flag indicating if the pair of keys were generated.
//     */
////    public static boolean areKeysPresent() {
////
////        File privateKey = new File(PRIVATE_KEY_FILE);
////        File publicKey = new File(PUBLIC_KEY_FILE);
////
////        if (privateKey.exists() && publicKey.exists()) {
////            return true;
////        }
////        return false;
////    }
//
//    /**
//     * Encrypt the plain text using public key.
//     *
//     * @param text
//     *            : original plain text
//     * @param key
//     *            :The public key
//     * @return Encrypted text
//     * @throws java.lang.Exception
//     */
//    public static byte[] encrypt(String text, PublicKey key) {
//        byte[] cipherText = null;
//        try {
//            // get an RSA cipher object and print the provider
//            Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
//            final Cipher cipher = Cipher.getInstance(PADDING, PROVIDER);
//
//            // encrypt the plain text using the public key
//            cipher.init(Cipher.ENCRYPT_MODE, key);
//            cipherText = cipher.doFinal(text.getBytes());
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return cipherText;
//    }
//
//    /**
//     * Decrypt text using private key.
//     *
//     * @param text
//     *            :encrypted text
//     * @param key
//     *            :The private key
//     * @return plain text
//     * @throws java.lang.Exception
//     */
//    public static String decrypt(byte[] text, PrivateKey key) {
//        byte[] dectyptedText = null;
//        try {
//            // get an RSA cipher object and print the provider
//            Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
//            final Cipher cipher = Cipher.getInstance(PADDING, PROVIDER);
//
//            // decrypt the text using the private key
//            cipher.init(Cipher.DECRYPT_MODE, key);
//            dectyptedText = cipher.doFinal(text);
//
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
//
//        return new String(dectyptedText);
//    }
//
//    public static String cipherText(String originalText) {
//        byte[] publicBytes = Base64.decodeBase64(PUCLIC_KEY);
//        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
//        try {
//            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
//            PublicKey publicKey = keyFactory.generatePublic(keySpec);
//            final byte[] cipherText = encrypt(originalText, publicKey);
//            // use String to hold cipher binary data
//            Base64 base64 = new Base64();
//            return base64.encodeToString(cipherText);
//            
//        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
//        } catch (InvalidKeySpecException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//    
//    public static String plainText(String cipherText) {
//        // use String to hold cipher binary data
//        Base64 base64 = new Base64();
//        // String cipherTextBase64 = base64.encodeToString(cipherText);
//        // String cipherTextBase64 = "FKEw8ux5/Sop7iPnk4VL/6owZ86EvC20Tc+v64nqWL9bQx7hrVV+deQ+zOIZ+GSrl83bP0xnaapsWZwPmE2lEZ5oFhuVz1/6h4jXGUXFoGzilI9TJpgMHWXcOWsmBN2wFzxWz/Pm5YYuSRnkcJZMEVXr6WuXsDckm1kpf3kFjgo=";
//        // get cipher binary data back from String
//        byte[] cipherTextArray = base64.decode(cipherText);
//
//        // Decrypt the cipher text using the private key.
////            inputStream = new ObjectInputStream(new FileInputStream(
////                    PRIVATE_KEY_FILE));
////            final PrivateKey privateKey = (PrivateKey) inputStream.readObject();
//
//        byte[] privateBytes = Base64.decodeBase64(PRIVATE_KEY);
//        PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(privateBytes);
//        KeyFactory keyFactory = null;
//        try {
//            keyFactory = KeyFactory.getInstance("RSA");
//            PrivateKey privateKey = keyFactory.generatePrivate(privateKeySpec);
//            final String plainText = decrypt(cipherTextArray, privateKey);
//            return plainText;
//        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
//        } catch (InvalidKeySpecException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//    /**
//     * Test the EncryptionUtil
//     */
//    public static void main(String[] args) {
//
//        try {
//
//            // Check if the pair of keys are present else generate those.
////            if (!areKeysPresent()) {
////                // Method generates a pair of keys using the RSA algorithm and
////                // stores it
////                // in their respective files
////                generateKey();
////            }
//
//            final String originalText = "12345678901234567890123456789012";
//            ObjectInputStream inputStream = null;
//
//            // Encrypt the string using the public key
////            inputStream = new ObjectInputStream(new FileInputStream(
////                    PUBLIC_KEY_FILE));
////            final PublicKey publicKey = (PublicKey) inputStream.readObject();
//            byte[] publicBytes = Base64.decodeBase64(PUCLIC_KEY);
//            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
//            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
//            PublicKey publicKey = keyFactory.generatePublic(keySpec);
//            final byte[] cipherText = encrypt(originalText, publicKey);
//
//            // use String to hold cipher binary data
//            Base64 base64 = new Base64();
//            // String cipherTextBase64 = base64.encodeToString(cipherText);
//            String cipherTextBase64 = "FKEw8ux5/Sop7iPnk4VL/6owZ86EvC20Tc+v64nqWL9bQx7hrVV+deQ+zOIZ+GSrl83bP0xnaapsWZwPmE2lEZ5oFhuVz1/6h4jXGUXFoGzilI9TJpgMHWXcOWsmBN2wFzxWz/Pm5YYuSRnkcJZMEVXr6WuXsDckm1kpf3kFjgo=";
//            // get cipher binary data back from String
//            byte[] cipherTextArray = base64.decode(cipherTextBase64);
//
//            // Decrypt the cipher text using the private key.
////            inputStream = new ObjectInputStream(new FileInputStream(
////                    PRIVATE_KEY_FILE));
////            final PrivateKey privateKey = (PrivateKey) inputStream.readObject();
//
//            byte[] privateBytes = Base64.decodeBase64(PRIVATE_KEY);
//            PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(privateBytes);
//            PrivateKey privateKey = keyFactory.generatePrivate(privateKeySpec);
//            final String plainText = decrypt(cipherTextArray, privateKey);
//
//            // Printing the Original, Encrypted and Decrypted Text
//            System.out.println("Original=" + originalText);
//            System.out.println("Encrypted=" + cipherTextBase64);
//            System.out.println("Decrypted=" + plainText);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
}
