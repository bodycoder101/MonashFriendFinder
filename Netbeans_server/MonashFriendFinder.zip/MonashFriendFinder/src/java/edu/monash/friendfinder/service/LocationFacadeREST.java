/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.monash.friendfinder.service;

import edu.monash.friendfinder.pojo.Location;
import edu.monash.friendfinder.pojo.LocationCount;
import edu.monash.friendfinder.pojo.LocationDistance;
import java.math.BigDecimal;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObjectBuilder;
import javax.persistence.TypedQuery;

/**
 * 
 * @author      lotus
 * @author      Binary Team
 * @version     1.0 25 Mar 2017
 * @since       1.0
 */
@Stateless
@Path("monashfriendfinder.location")
public class LocationFacadeREST extends AbstractFacade<Location> {

    @PersistenceContext(unitName = "MonashFriendFinderPU")
    private EntityManager em;

    public LocationFacadeREST() {
        super(Location.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Location entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Location entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Location find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Location> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Location> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    /** 
     * Assigment 2 task 6 a)
     *
     * @param locationId    location ID
     * @return              location information with format of JSON
     * @since               1.0
     */
    @GET
    @Path("Location.findCurrentLocationByStudentId/{studentIds}")
    @Produces({"application/json"})
    public String findCurrentLocationByStudentId(@PathParam("studentIds") String studentIds) {
        String[] ids = studentIds.split("&&");
        StringBuilder stringBuilder = new StringBuilder();
        for (String id : ids) {
            stringBuilder.append(id).append(",");
        }
        String sql = null;
        String tempSql = stringBuilder.toString();
        if (stringBuilder.toString().endsWith(",")) {
            sql = tempSql.substring(0,tempSql.length() - 1);
        }
        Query query = em.createNativeQuery("select p.student_id, p.first_name, p.sur_name, p.DOB, p.gender, l.longtitude, l.latitude from profile p, location l where p.student_id = l.student_id and l.student_id in ("  + sql + " ) and l.current = 0");
        List<Object[]> data = query.getResultList();
        JsonBuilderFactory f = Json.createBuilderFactory(null);
        JsonArrayBuilder arrayBuilder = f.createArrayBuilder();
        for (Object[] object : data) {
            JsonObjectBuilder json = f.createObjectBuilder();
            json.add("student_id", object[0].toString());
            json.add("first_name", object[1].toString());
            json.add("sur_name", object[2].toString());
            json.add("DOB", object[3].toString());
            json.add("gender", object[4].toString());
            json.add("longtitude", object[5].toString());
            json.add("latitude", object[6].toString());
            arrayBuilder.add(json);
        }
        // JsonObjectBuilder result = f.createObjectBuilder();
        // result.add("data", arrayBuilder);
        return arrayBuilder.build().toString();
    }
    
    /** 
     * Assigment 2 task 7 b)
     *
     * @param locationId    location ID
     * @return              location information with format of JSON
     * @since               1.0
     */
    @GET
    @Path("Location.locationFrequencies/{studentId}/{startDate}/{endDate}")
    @Produces({"application/json"})
    public String locationFrequencies(@PathParam("studentId") String studentId, @PathParam("startDate") String startDate, @PathParam("endDate") String endDate) {
        System.out.println("Student ID: " + studentId + "request location and its frequencies data.");
        Query query = em.createNativeQuery("select location_name, count(*) from location where student_id = ? and time >= ? and time <= ? GROUP BY location_name");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<Object[]> result;
        JsonBuilderFactory f = Json.createBuilderFactory(null);
        JsonObjectBuilder json = f.createObjectBuilder();
        try {
            Timestamp start = new Timestamp(sdf.parse(startDate).getTime());
            Timestamp end =  new Timestamp(sdf.parse(endDate).getTime());
            query.setParameter(1, studentId);
            query.setParameter(2, start);
            query.setParameter(3, end);
            result = query.getResultList();
            json.add("records", result.size());
            JsonArrayBuilder arrayBuilder = f.createArrayBuilder();
            for (int i = 0; i < result.size(); i++) {
                Object[] object = result.get(i);
                arrayBuilder.add(object[0].toString());
                arrayBuilder.add(object[1].toString());
            }
            json.add("data", arrayBuilder);
        } catch (ParseException ex) {
            Logger.getLogger(LocationFacadeREST.class.getName()).log(Level.SEVERE, null, ex);
        }
        String temp = json.build().toString();
        System.out.println(temp);
        return temp;
    }
    
    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param locationId    location ID
     * @return              location information with format of JSON
     * @since               1.0
     */
    @GET
    @Path("Location.findByLocationId/{locationId}")
    @Produces({"application/json"})
    public List<Location> findByLocationId(@PathParam("locationId") Integer locationId) {
        Query query = em.createNamedQuery("Location.findByLocationId");
        query.setParameter("locationId", locationId);
        return query.getResultList();
    }

    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param latitude    latitude
     * @return            location information with format of JSON
     * @since             1.0
     */
    @GET
    @Path("Location.findByLatitude/{latitude}")
    @Produces({"application/json"})
    public List<Location> findByLatitude(@PathParam("latitude") Double latitude) {
        Query query = em.createNamedQuery("Location.findByLatitude");
        query.setParameter("latitude", latitude);
        return query.getResultList();
    }

    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param longtitude    longtitude
     * @return              location information with format of JSON
     * @since               1.0
     */
    @GET
    @Path("Location.findByLongtitude/{longtitude}")
    @Produces({"application/json"})
    public List<Location> findByLongtitude(@PathParam("longtitude") Double longtitude) {
        Query query = em.createNamedQuery("Location.findByLongtitude");
        query.setParameter("longtitude", longtitude);
        return query.getResultList();
    }

    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param time    time
     * @return        location information with format of JSON
     * @since         1.0
     */
    @GET
    @Path("Location.findByTime/{time}")
    @Produces({"application/json"})
    public List<Location> findByTime(@PathParam("time") Timestamp time) {
        Query query = em.createNamedQuery("Location.findByTime");
        query.setParameter("time", time);
        return query.getResultList();
    }

    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param locationName      location name
     * @return                  location information with format of JSON
     * @since                   1.0
     */
    @GET
    @Path("Location.findByLocationName/{locationName}")
    @Produces({"application/json"})
    public List<Location> findByLocationName(@PathParam("locationName") String locationName) {
        Query query = em.createNamedQuery("Location.findByLocationName");
        query.setParameter("locationName", locationName);
        return query.getResultList();
    }

    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param studentId    student ID
     * @return             location information related to the student with format of JSON
     * @since              1.0
     */
    @GET
    @Path("Location.findBystudentId/{studentId}")
    @Produces({"application/json"})
    public List<Location> findBystudentId(@PathParam("studentId") Integer studentId) {
        Query query = em.createNamedQuery("Location.findBystudentId");
        query.setParameter("studentId", studentId);
        return query.getResultList();
    }
    
    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param current    current
     * @return           location information with format of JSON
     * @since            1.0
     */
    @GET
    @Path("Location.findByCurrent/{current}")
    @Produces({"application/json"})
    public List<Location> findByCurrent(@PathParam("current") Integer current) {
        Query query = em.createNamedQuery("Location.findByCurrent");
        query.setParameter("current", current);
        return query.getResultList();
    }

    /** 
     * Assigment 1 task 2 b)-3)
     *             Implicit join and Dynamic query for Profile and Location, use gender of profile and location_name of location to query.
     * 
     * @param  gender           student gender
     * @param  locationName     location name
     * @return                  location information with format of JSON
     * @since                   1.0
     */
    @GET
    @Path("findByGenderOfStudentAndLocationNameOfLocation/{gender}/{locationName}")
    @Produces({"application/json"})
    public List<Location> findByGenderOfStudentAndLocationNameOfLocation(@PathParam("gender") String gender, @PathParam("locationName") String locationName) {
        TypedQuery<Location> q = em.createQuery("SELECT p FROM Location p WHERE p.studentId.gender = :gender AND p.locationName = :locationName", Location.class);
        q.setParameter("gender", gender);
        q.setParameter("locationName", locationName);
        return q.getResultList();
    }

    /** 
     * Assigment 1 task 3 a)
     * 
     * @param  startingDate   started time of the friendship
     * @param  endingDate     ended Time of the friendship
     * @param  studentId      student ID
     * @return                a list of the place names and their frequency
     * @since                 1.0
     */
    @GET
    @Path("Location.findByDateANDPrimaryKey/{startingDate}/{endingDate}/{studentId}")
    @Produces({"application/json"})
    public List<LocationCount> findByDateANDPrimaryKey(@PathParam("startingDate") String startingDate,
            @PathParam("endingDate") String endingDate, @PathParam("studentId") Integer studentId) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Timestamp starting = new Timestamp(sdf.parse(startingDate).getTime());
            Timestamp ending = new Timestamp(sdf.parse(endingDate).getTime());
            Query q = em.createQuery("SELECT l.locationName, COUNT(l.studentId) FROM Location l WHERE l.time >= :startingDate AND l.time <= :endingDate AND l.studentId.studentId = :studentId GROUP BY l.locationName");
            q.setParameter("startingDate", starting);
            q.setParameter("endingDate", ending);
            q.setParameter("studentId", studentId);
            List<Object[]> data = q.getResultList();
            List<LocationCount> result = new ArrayList<>();
            for (Object[] objects : data) {
                LocationCount lc = new LocationCount();
                lc.setLocationName(objects[0].toString());
                lc.setCount(objects[1].toString());
                result.add(lc);
            }
            return result;
        } catch (ParseException ex) {
            Logger.getLogger(LocationFacadeREST.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    /** 
     * Assigment 1 task 3 b)
     * 
     * @param  studentId   studentId
     * @param  longitude   longitude
     * @param  latitude    latitude
     * @return             a list of the all the other subscribed students based on 
     *                     their distance from this student (since you will have a limited 
     *                     number of records, we do not limit this but you can limit 
     *                     the list to 10 closest ones).
     * @since              1.0
     */
    @GET
    @Path("Location.findByStudentIdANDLongitudeANDLatitude/{studentId}/{longitude}/{latitude}")
    @Produces({"application/json"})
    public List<LocationDistance> findByStudentIdANDLongitudeANDLatitude(@PathParam("studentId") Integer studentId,
            @PathParam("longitude") Double longitude, @PathParam("latitude") Double latitude) {
        /*
         * The best way to solve this requirement is to define a MySQL function because of the huge cost of transmitting all the needed records
         * like the following annotated SQL sentence. But it failed when coded and no solution was found.
         * Query q = em.createQuery("select distinct p.firstName, p.surName, l.longtitude, l.latitude, function ('fn_distance_count', l.longtitude, l.latitude, :longitude, :latitude) AS distance from Location l join Profile p on l.studentId = p.studentId where p.studentId <> :studentId AND l.current = 0 ORDER BY distance limit 10");
         */
        Query q = em.createNativeQuery("select distinct p.first_name, p.sur_name, l.longtitude, l.latitude from location l, profile p where l.student_id = p.student_id and l.student_id <> ? AND l.current = 0 ");
        q.setParameter(1, studentId);
        List<Object[]> data = q.getResultList();
        Map<Double, LocationDistance> resultMap = new TreeMap<>();
        for (Object[] objects : data) {
            LocationDistance ld = new LocationDistance();
            ld.setFirstName(objects[0].toString());
            ld.setSurName(objects[1].toString());
            double inputLongitude = Double.parseDouble(objects[2].toString());
            double inputLatitude = Double.parseDouble(objects[3].toString());
            double distance = calculateDistance(inputLongitude, inputLatitude, longitude, latitude);
            ld.setLongitude(inputLongitude);
            ld.setLatitude(inputLatitude);
            resultMap.put(distance, ld);
        }
        int count = 0;
        List<LocationDistance> result = new ArrayList<>(10);
        for (Double key : resultMap.keySet()) {
            if (count > 9) {
                break;
            }
            
            LocationDistance item = resultMap.get(key);
            result.add(item);
            count++;
        }
        return result;
    }
    
    /** 
     * This method is an assisted method that used to calculate the distance between two students
     * 
     * @param  lon1    the longitude of the first student
     * @param  lat1    the latitude of the first student
     * @param  lon2    the longitude of the second student
     * @param  lat2    the latitude of the second student
     * @return         the distance between two students
     * @since          1.0
     */
    private double calculateDistance(double lon1,double lat1,double lon2, double lat2) {
        double radLat1 = rad(lat1);
        double radLat2 = rad(lat2);
        double a = radLat1 - radLat2;
        double b = rad(lon1) - rad(lon2);
        double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a/2),2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b/2),2))); 
        /*
         * EARTH_RADIUS: 6378137;
         */
        s = s * 6378137;
        /*
         * the unit of the returned value is meter.
        */
        return s; 
    }
    
    /** 
     * This method is an assisted method that used to calculate the radius according to the given number
     * 
     * @param  d   the given number 
     * @return     the radius
     * @since      1.0
     */
    private double rad(double d){
        return d * Math.PI / 180.0;
    }
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

}
