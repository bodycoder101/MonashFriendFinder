/*
 * @(#)FriendshipFacadeREST.java        1.0 2017/03/25
 *
 * Copyright (c) 2017-2017 Binary Team, Monash University.
 * Public College Building No.7, No.377 Linquan Street, 
 * Dushu Lake Science and Education Innovation Zone, Industrial Park, Suzhou, China. 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Binary Team,
 * Monash University. You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement 
 * you entered into with Binary Team.
 */
package edu.monash.friendfinder.service;

import edu.monash.friendfinder.pojo.Friendship;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * 
 * @author      lotus
 * @author      Binary Team
 * @version     1.0 25 Mar 2017
 * @since       1.0
 */
@Stateless
@Path("monashfriendfinder.friendship")
public class FriendshipFacadeREST extends AbstractFacade<Friendship> {

    @PersistenceContext(unitName = "MonashFriendFinderPU")
    private EntityManager em;

    public FriendshipFacadeREST() {
        super(Friendship.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Friendship entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Friendship entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Friendship find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Friendship> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Friendship> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }
    
    /** 
     * Assigment 2 task 4 d)
     *
     * @param endingTime    ended Time of the friendship
     * @return              friendship information with format of JSON
     * @since               1.0
     */
    
    @POST
    @Path("Friendship.addFriendships/{userId}/{friendId}")
    @Produces({"application/json"})
    public String addFriendships(@PathParam("userId") String userId, @PathParam("friendId") String friendId) {
        Query query = null;
//        String existsFriendship = "select count(*) from friendship where user_id = ? or friend_id = ?";
//        query = em.createNativeQuery(existsFriendship);
//        query.setParameter(1, userId);
//        query.setParameter(2, friendId);
//        int rows = query.getResultList().size();
//        if (rows > 0) {
//            return "true";
//        }
        String sql = "INSERT INTO friendship(user_id, friend_id, starting_time) values(?, ?, ?) ";
        query = em.createNativeQuery(sql);
        query.setParameter(1, userId);
        query.setParameter(2, friendId);
        query.setParameter(3, new Timestamp(new Date().getTime()));
        int count = query.executeUpdate();
        if (count > 0) {
            return "true";
        }
        return "false";
    }
    
    /** 
     * Assigment 2 task 4 e)
     *
     * @param endingTime    ended Time of the friendship
     * @return              friendship information with format of JSON
     * @since               1.0
     */
    
    @DELETE
    @Path("Friendship.deleteFriendships/{userId}/{friendId}")
    @Produces({"application/json"})
    public String deleteFriendships(@PathParam("userId") String userId, @PathParam("friendId") String friendId) {
        String sql = "update friendship set ending_time = ? where user_id = ? and friend_id = ?";
        Query query = em.createNativeQuery(sql);
        query.setParameter(1, new Timestamp(new Date().getTime()));
        query.setParameter(2, userId);
        query.setParameter(3, friendId);
        int count = query.executeUpdate();
        if (count > 0) {
            return "true";
        }
        return "false";
    }

    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param friendshipId    primary key of the records stored in this table
     * @return                friendship information with format of JSON
     * @since                 1.0
     */
    @GET
    @Path("Friendship.findByFriendshipId/{friendshipId}")
    @Produces({"application/json"})
    public List<Friendship> findByFriendshipId(@PathParam("friendshipId") Integer friendshipId) {
        Query query = em.createNamedQuery("Friendship.findByFriendshipId");
        query.setParameter("friendshipId", friendshipId);
        return query.getResultList();
    }
    
    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param startingTime    started time of the friendship
     * @return                friendship information with format of JSON
     * @since                 1.0
     */
    @GET
    @Path("Friendship.findByStartingTime/{startingTime}")
    @Produces({"application/json"})
    public List<Friendship> findByStartingTime(@PathParam("startingTime") Timestamp startingTime) {
        Query query = em.createNamedQuery("Friendship.findByStartingTime");
        query.setParameter("startingTime", startingTime);
        return query.getResultList();
    }
    
    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param endingTime    ended Time of the friendship
     * @return              friendship information with format of JSON
     * @since               1.0
     */
    @GET
    @Path("Friendship.findByEndingTime/{endingTime}")
    @Produces({"application/json"})
    public List<Friendship> findByEndingTime(@PathParam("endingTime") Timestamp endingTime) {
        Query query = em.createNamedQuery("Friendship.findByEndingTime");
        query.setParameter("endingTime", endingTime);
        return query.getResultList();
    }
    
    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param userId    user ID of the student owned the friendship
     * @return          friendship information with format of JSON
     * @since           1.0
     */
    @GET
    @Path("Friendship.findByUserId/{userId}")
    @Produces({"application/json"})
    public List<Friendship> findByUserId(@PathParam("userId") Integer userId) {
        Query query = em.createNamedQuery("Friendship.findByUserId");
        query.setParameter("userId", userId);
        return query.getResultList();
    }
    
    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param friendId    friend ID of the student made a friendship with another student 
     * @return            friendship information with format of JSON
     * @since             1.0
     */
    @GET
    @Path("Friendship.findByFriendId/{friendId}")
    @Produces({"application/json"})
    public List<Friendship> findByFriendId(@PathParam("friendId") Integer friendId) {
        Query query = em.createNamedQuery("Friendship.findByFriendId");
        query.setParameter("friendId", friendId);
        return query.getResultList();
    }
    
    //task 2 b)--4):Explict join and Static query for Profile and Friendship, use address and  currendJob of profile to query.
    @GET
    @Path("findByCurrentJobAndAddressOfProfile/{currentJob}/{address}/{friendId}")
    @Produces({"application/json"})
    public List<Friendship> findByCurrentJobAndAddressOfProfile(@PathParam("currentJob") String CurrentJob, @PathParam("address") String Address, @PathParam("friendId") Integer FriendId) {
        Query query = em.createNamedQuery("findByCurrentJobAndAddressOfProfile");
        query.setParameter("currentJob",CurrentJob);
        query.setParameter("address", Address);
        query.setParameter("friendId",FriendId);
        return query.getResultList();
    }
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
