/*
 * @(#)SlecetedCourse.java        1.0 2017/03/25
 *
 * Copyright (c) 2017-2017 Binary Team, Monash University.
 * Public College Building No.7, No.377 Linquan Street, 
 * Dushu Lake Science and Education Innovation Zone, Industrial Park, Suzhou, China. 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Binary Team,
 * Monash University. You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement 
 * you entered into with Binary Team.
 */
package edu.monash.friendfinder.pojo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * @author      lotus
 * @author      Binary Team
 * @version     1.0 25 Mar 2017
 * @since       1.0
 */
@Entity
@Table(name = "sleceted_course")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SlecetedCourse.findAll", query = "SELECT s FROM SlecetedCourse s")
    , @NamedQuery(name = "SlecetedCourse.findByCourseId", query = "SELECT s FROM SlecetedCourse s WHERE s.courseId.courseId = :courseId")
    , @NamedQuery(name = "SlecetedCourse.findBystudentId", query = "SELECT s FROM SlecetedCourse s WHERE s.studentId.studentId = :studentId")
    , @NamedQuery(name = "SlecetedCourse.findByScId", query = "SELECT s FROM SlecetedCourse s WHERE s.scId = :scId")})
public class SlecetedCourse implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "sc_id")
    private Integer scId;
    @JoinColumn(name = "course_id", referencedColumnName = "course_id")
    @ManyToOne
    private Course courseId;
    @JoinColumn(name = "student_id", referencedColumnName = "student_id")
    @ManyToOne
    private Profile studentId;

    public SlecetedCourse() {
    }

    public SlecetedCourse(Integer scId) {
        this.scId = scId;
    }

    public Integer getScId() {
        return scId;
    }

    public void setScId(Integer scId) {
        this.scId = scId;
    }

    public Course getCourseId() {
        return courseId;
    }

    public void setCourseId(Course courseId) {
        this.courseId = courseId;
    }

    public Profile getStudentId() {
        return studentId;
    }

    public void setStudentId(Profile studentId) {
        this.studentId = studentId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (scId != null ? scId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SlecetedCourse)) {
            return false;
        }
        SlecetedCourse other = (SlecetedCourse) object;
        if ((this.scId == null && other.scId != null) || (this.scId != null && !this.scId.equals(other.scId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "MonashFriendFinder.pojo.SlecetedCourse[ scId=" + scId + " ]";
    }
    
}
