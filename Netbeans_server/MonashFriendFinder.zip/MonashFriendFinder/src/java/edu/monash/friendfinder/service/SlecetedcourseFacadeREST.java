/*
 * @(#)SlecetedcourseFacadeREST.java        1.0 2017/03/25
 *
 * Copyright (c) 2017-2017 Binary Team, Monash University.
 * Public College Building No.7, No.377 Linquan Street, 
 * Dushu Lake Science and Education Innovation Zone, Industrial Park, Suzhou, China. 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Binary Team,
 * Monash University. You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement 
 * you entered into with Binary Team.
 */
package edu.monash.friendfinder.service;

import edu.monash.friendfinder.pojo.SlecetedCourse;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * 
 * @author      lotus
 * @author      Binary Team
 * @version     1.0 25 Mar 2017
 * @since       1.0
 */
@Stateless
@Path("monashfriendfinder.pojo.slecetedcourse")
public class SlecetedcourseFacadeREST extends AbstractFacade<SlecetedCourse> {

    @PersistenceContext(unitName = "MonashFriendFinderPU")
    private EntityManager em;

    public SlecetedcourseFacadeREST() {
        super(SlecetedCourse.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(SlecetedCourse entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, SlecetedCourse entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public SlecetedCourse find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<SlecetedCourse> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<SlecetedCourse> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }
    
    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param scId    primary key of the records stored in this table
     * @return        selected course information with format of JSON
     * @since         1.0
     */
    @GET
    @Path("Slecetedcourse.findByScId/{scId}")
    @Produces({"application/json"})
    public List<SlecetedCourse> findBySdId(@PathParam("scId") Integer scId) {
        Query query = em.createNamedQuery("Slecetedcourse.findByScId");
        query.setParameter("scId", scId);
        return query.getResultList();
    }
    
    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param courseId    selected course ID
     * @return            selected course information with format of JSON
     * @since             1.0
     */
    @GET
    @Path("Slecetedcourse.findByCourseId/{CourseId}")
    @Produces({"application/json"})
    public List<SlecetedCourse> findByCourseId(@PathParam("CourseId") Integer courseId) {
        Query query = em.createNamedQuery("Slecetedcourse.findByCourseId");
        query.setParameter("courseId",courseId);
        return query.getResultList();
    }
    
    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param studentId    student ID
     * @return             selected course information that the given student has selected with format of JSON
     * @since              1.0
     */
    @GET
    @Path("Slecetedcourse.findBystudentId/{studentId}")
    @Produces({"application/json"})
    public List<SlecetedCourse> findBystudentId(@PathParam("studentId") Integer studentId) {
        Query query = em.createNamedQuery("Slecetedcourse.findBystudentId");
        query.setParameter("studentId", studentId);
        return query.getResultList();
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
