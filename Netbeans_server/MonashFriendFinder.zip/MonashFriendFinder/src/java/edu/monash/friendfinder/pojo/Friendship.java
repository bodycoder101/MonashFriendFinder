/*
 * @(#)Friendship.java        1.0 2017/03/25
 *
 * Copyright (c) 2017-2017 Binary Team, Monash University.
 * Public College Building No.7, No.377 Linquan Street, 
 * Dushu Lake Science and Education Innovation Zone, Industrial Park, Suzhou, China. 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Binary Team,
 * Monash University. You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement 
 * you entered into with Binary Team.
 */
package edu.monash.friendfinder.pojo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * @author      lotus
 * @author      Binary Team
 * @version     1.0 25 Mar 2017
 * @since       1.0
 */
@Entity
@Table(name = "friendship")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Friendship.findAll", query = "SELECT f FROM Friendship f")
    , @NamedQuery(name = "Friendship.findByFriendshipId", query = "SELECT f FROM Friendship f WHERE f.friendshipId = :friendshipId")
    , @NamedQuery(name = "Friendship.findByStartingTime", query = "SELECT f FROM Friendship f WHERE f.startingTime = :startingTime")
    , @NamedQuery(name = "Friendship.findByUserId", query = "SELECT f FROM Friendship f WHERE f.userId.studentId = :userId and f.endingTime = null")// 
    , @NamedQuery(name = "Friendship.findByFriendId", query = "SELECT f FROM Friendship f WHERE f.friendId.studentId = :friendId")
    , @NamedQuery(name = "findByCurrentJobAndAddressOfProfile", query = "SELECT f FROM Friendship f INNER JOIN FETCH f.friendId c WHERE c.address = :address AND c.currentJob = :currentJob AND c.studentId = :friendId")
    , @NamedQuery(name = "Friendship.findByEndingTime", query = "SELECT f FROM Friendship f WHERE f.endingTime = :endingTime")})
public class Friendship implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "friendship_id")
    private Integer friendshipId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "starting_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startingTime;
    @Column(name = "ending_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endingTime;
    @JoinColumn(name = "user_id", referencedColumnName = "student_id")
    @ManyToOne(optional = false)
    private Profile userId;
    @JoinColumn(name = "friend_id", referencedColumnName = "student_id")
    @ManyToOne(optional = false)
    private Profile friendId;

    public Friendship() {
    }

    public Friendship(Integer friendshipId) {
        this.friendshipId = friendshipId;
    }

    public Friendship(Integer friendshipId, Date startingTime) {
        this.friendshipId = friendshipId;
        this.startingTime = startingTime;
    }

    public Integer getFriendshipId() {
        return friendshipId;
    }

    public void setFriendshipId(Integer friendshipId) {
        this.friendshipId = friendshipId;
    }

    public Date getStartingTime() {
        return startingTime;
    }

    public void setStartingTime(Date startingTime) {
        this.startingTime = startingTime;
    }

    public Date getEndingTime() {
        return endingTime;
    }

    public void setEndingTime(Date endingTime) {
        this.endingTime = endingTime;
    }

    public Profile getUserId() {
        return userId;
    }

    public void setUserId(Profile userId) {
        this.userId = userId;
    }

    public Profile getFriendId() {
        return friendId;
    }

    public void setFriendId(Profile friendId) {
        this.friendId = friendId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (friendshipId != null ? friendshipId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Friendship)) {
            return false;
        }
        Friendship other = (Friendship) object;
        if ((this.friendshipId == null && other.friendshipId != null) || (this.friendshipId != null && !this.friendshipId.equals(other.friendshipId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "MonashFriendFinder.Friendship[ friendshipId=" + friendshipId + " ]";
    }
    
}
