/*
 * @(#)ApplicationConfig.java        1.0 2017/03/25
 *
 * Copyright (c) 2017-2017 Binary Team, Monash University.
 * Public College Building No.7, No.377 Linquan Street, 
 * Dushu Lake Science and Education Innovation Zone, Industrial Park, Suzhou, China. 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Binary Team,
 * Monash University. You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement 
 * you entered into with Binary Team.
 */
package edu.monash.friendfinder.service;

import java.util.Set;
import javax.ws.rs.core.Application;

/**
 * 
 * @author      lotus
 * @author      Binary Team
 * @version     1.0 25 Mar 2017
 * @since       1.0
 */
@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(edu.monash.friendfinder.service.CourseFacadeREST.class);
        resources.add(edu.monash.friendfinder.service.FriendshipFacadeREST.class);
        resources.add(edu.monash.friendfinder.service.LocationFacadeREST.class);
        resources.add(edu.monash.friendfinder.service.ProfileFacadeREST.class);
        resources.add(edu.monash.friendfinder.service.SlecetedcourseFacadeREST.class);
    }
    
}
