/*
 * @(#)Location.java        1.0 2017/03/25
 *
 * Copyright (c) 2017-2017 Binary Team, Monash University.
 * Public College Building No.7, No.377 Linquan Street, 
 * Dushu Lake Science and Education Innovation Zone, Industrial Park, Suzhou, China. 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Binary Team,
 * Monash University. You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement 
 * you entered into with Binary Team.
 */
package edu.monash.friendfinder.pojo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * @author      lotus
 * @author      Binary Team
 * @version     1.0 25 Mar 2017
 * @since       1.0
 */
@Entity
@Table(name = "location")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Location.findAll", query = "SELECT l FROM Location l")
    , @NamedQuery(name = "Location.findByLocationId", query = "SELECT l FROM Location l WHERE l.locationId = :locationId")
    , @NamedQuery(name = "Location.findByLatitude", query = "SELECT l FROM Location l WHERE l.latitude = :latitude")
    , @NamedQuery(name = "Location.findByLongtitude", query = "SELECT l FROM Location l WHERE l.longtitude = :longtitude")
    , @NamedQuery(name = "Location.findByTime", query = "SELECT l FROM Location l WHERE l.time = :time")
    , @NamedQuery(name = "Location.findBystudentId", query = "SELECT l FROM Location l WHERE l.studentId.studentId = :studentId")
    , @NamedQuery(name = "Location.findByCurrent", query = "SELECT l FROM Location l WHERE l.current = :current")
    , @NamedQuery(name = "Location.findByLocationName", query = "SELECT l FROM Location l WHERE l.locationName = :locationName")})
public class Location implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "location_id")
    private Integer locationId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "latitude")
    private Double latitude;
    @Basic(optional = false)
    @NotNull
    @Column(name = "longtitude")
    private Double longtitude;
    @Basic(optional = false)
    @NotNull
    @Column(name = "time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date time;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "location_name")
    private String locationName;
    @Basic(optional = false)
    @NotNull
    @Column(name = "current")
    private Integer current;
    @JoinColumn(name = "student_id", referencedColumnName = "student_id")
    @ManyToOne(optional = false)
    private Profile studentId;

    public Location() {
    }

    public Location(Integer locationId) {
        this.locationId = locationId;
    }

    public Location(Integer locationId, Double latitude, Double longtitude, Date time, String locationName, Integer current) {
        this.locationId = locationId;
        this.latitude = latitude;
        this.longtitude = longtitude;
        this.time = time;
        this.locationName = locationName;
        this.current = current;
    }

    public Integer getLocationId() {
        return locationId;
    }

    public void setLocationId(Integer locationId) {
        this.locationId = locationId;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(Double longtitude) {
        this.longtitude = longtitude;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public Profile getStudentId() {
        return studentId;
    }

    public void setStudentId(Profile studentId) {
        this.studentId = studentId;
    }

    public void setCurrent(Integer current) {
        this.current = current;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Integer getCurrent() {
        return current;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (locationId != null ? locationId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Location)) {
            return false;
        }
        Location other = (Location) object;
        if ((this.locationId == null && other.locationId != null) || (this.locationId != null && !this.locationId.equals(other.locationId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "MonashFriendFinder.Location[ locationId=" + locationId + " ]";
    }
    
}
