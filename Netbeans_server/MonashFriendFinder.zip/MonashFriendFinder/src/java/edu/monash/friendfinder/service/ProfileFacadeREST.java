/*
 * @(#)ProfileFacadeREST.java        1.0 2017/03/25
 *
 * Copyright (c) 2017-2017 Binary Team, Monash University.
 * Public College Building No.7, No.377 Linquan Street, 
 * Dushu Lake Science and Education Innovation Zone, Industrial Park, Suzhou, China. 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Binary Team,
 * Monash University. You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement 
 * you entered into with Binary Team.
 */
package edu.monash.friendfinder.service;

import edu.monash.friendfinder.pojo.FavouriteUnit;
import edu.monash.friendfinder.pojo.Profile;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObjectBuilder;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author lotus
 * @author Binary Team
 * @version 1.0 25 Mar 2017
 * @since 1.0
 */
@Stateless
@Path("monashfriendfinder.profile")
public class ProfileFacadeREST extends AbstractFacade<Profile> {

    @PersistenceContext(unitName = "MonashFriendFinderPU")
    private EntityManager em;

    public ProfileFacadeREST() {
        super(Profile.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Profile entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Profile entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Profile find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Profile> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Profile> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param studentId student ID
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByStudentId/{studentId}")
    @Produces({"application/json"})
    public List<Profile> findByStudentId(@PathParam("studentId") Integer studentId) {
        Query query = em.createNamedQuery("Profile.findByStudentId");
        query.setParameter("studentId", studentId);
        return query.getResultList();
    }

    /**
     * Assigment 2 task 3 b)
     *
     * @param surName the surname of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @POST
    @Path("Profile.login/{email}/{emailPassword}")
    @Produces({"application/json"})
    public Profile login(@PathParam("email") String email, @PathParam("emailPassword") String emailPassword) {

        try {
            TypedQuery<Profile> q = em.createQuery("SELECT p FROM Profile p WHERE p.monashEmail = :email AND p.password = :emailPassword", Profile.class);
            q.setParameter("email", email);
            q.setParameter("emailPassword", emailPassword);
            List<Profile> result = q.getResultList();
            if (q.getResultList().size() > 0) {
                Profile profile = result.get(0);
                return profile;
            }
        } catch (Exception ex) {
            Logger.getLogger(ProfileFacadeREST.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new Profile();
    }
    
    /**
     * Assigment 2 task 3 c)
     *
     * @param studentId student ID
     * @return student information with format of JSON
     * @since 1.0
     */
    @POST
    @Path("Profile.register/{firstName}/{surName}/{doB}/{gender}/{address}/{suburb}/{nationality}/{nativeLanguage}/{favouriteMovie}/{favouriteUnit}/{favouriteSport}/{currentJob}/{monashEmail}/{password}/{studyMode}/{subscriptionDatetime}")
    @Produces({"application/json"})
    public String register(@PathParam("firstName") String firstName, @PathParam("surName") String surName,
            @PathParam("doB") String doB, @PathParam("gender") String gender,
            @PathParam("address") String address, @PathParam("suburb") String suburb, @PathParam("nationality") String nationality,
            @PathParam("nativeLanguage") String nativeLanguage, @PathParam("favouriteMovie") String favouriteMovie, @PathParam("favouriteUnit") String favouriteUnit,
            @PathParam("favouriteSport") String favouriteSport, @PathParam("currentJob") String currentJob, @PathParam("monashEmail") String monashEmail,
            @PathParam("password") String password, @PathParam("studyMode") String studyMode, @PathParam("subscriptionDatetime") String subscriptionDatetime) {
        StringBuilder sql = new StringBuilder("insert into profile (first_name, sur_name, DOB, gender, address, suburb, ")
                .append("nationality, native_language, favourite_movie, favourite_unit, favourite_sport, ")
                .append("current_job, s_password, monash_email, study_mode, subscription_datetime) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        // check whether the email exists
        String emailExists = "select student_id from Profile where monash_email = ?";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Query q = em.createNativeQuery(emailExists);
        q.setParameter(1, monashEmail);
        if (q.getResultList().size() > 0) {
            return "exists";
        }
        Timestamp birthday = null;
        Timestamp subscription = null;
        try {
            birthday = new Timestamp(sdf.parse(doB).getTime());
            subscription = new Timestamp(sdf.parse(subscriptionDatetime).getTime());
        } catch (ParseException ex) {
            Logger.getLogger(ProfileFacadeREST.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        q = em.createNativeQuery(sql.toString());
        q.setParameter(1, firstName);
        q.setParameter(2, surName);
        q.setParameter(3, birthday);
        q.setParameter(4, gender);
        q.setParameter(5, address);
        q.setParameter(6, suburb);
        q.setParameter(7, nationality);
        q.setParameter(8, nativeLanguage);
        q.setParameter(9, favouriteMovie);
        q.setParameter(10, favouriteUnit);
        q.setParameter(11, favouriteSport);
        q.setParameter(12, currentJob);
        q.setParameter(13, password);
        q.setParameter(14, monashEmail);
        q.setParameter(15, studyMode);
        q.setParameter(16, subscription);
        // insert success
        if (q.executeUpdate() > 0) {
            // query to get the student ID
            q = em.createNativeQuery(emailExists);
            q.setParameter(1, monashEmail);
            return q.getResultList().get(0).toString();
        }
        return "false";
    }

    /**
     * Assigment 2 task 4 a)
     *
     * @param surName the surname of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @PUT
    @Path("Profile.update/{studentId}/{firstName}/{surName}/{doB}/{gender}/{address}/{suburb}/{nationality}/{nativeLanguage}/{favouriteMovie}/{favouriteSport}/{password}")
    @Produces({"application/json"})
    public String update(@PathParam("studentId") String studentId,
            @PathParam("firstName") String firstName, @PathParam("surName") String surName,
            @PathParam("doB") String doB, @PathParam("gender") String gender,
            @PathParam("address") String address, @PathParam("suburb") String suburb, @PathParam("nationality") String nationality,
            @PathParam("nativeLanguage") String nativeLanguage, @PathParam("favouriteMovie") String favouriteMovie,
            @PathParam("favouriteSport") String favouriteSport, @PathParam("password") String password) {
        StringBuilder sql = new StringBuilder("UPDATE profile SET first_name = ?, sur_name = ?, DOB = ?, ")
                .append("gender = ?, address = ?, suburb = ?, nationality = ?, native_language = ?, ")
                .append("favourite_movie = ?, favourite_sport = ?, s_password = ? WHERE student_id = ? ");
        Query q = em.createNativeQuery(sql.toString());
        q.setParameter(1, firstName);
        q.setParameter(2, surName);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Timestamp timestamp = null;
        try {
            timestamp = new Timestamp(sdf.parse(doB).getTime());
        } catch (ParseException ex) {
            Logger.getLogger(ProfileFacadeREST.class.getName()).log(Level.SEVERE, null, ex);
        }
        q.setParameter(3, timestamp);
        q.setParameter(4, gender);
        q.setParameter(5, address);
        q.setParameter(6, suburb);
        q.setParameter(7, nationality);
        q.setParameter(8, nativeLanguage);
        q.setParameter(9, favouriteMovie);
        q.setParameter(10, favouriteSport);
        q.setParameter(11, password);
        q.setParameter(12, studentId);
        int rows = q.executeUpdate();
        if (rows > 0) {
            return "true";
        }
        return "false";
    }
    
    /**
     * Assigment 2 task 7 a)
     *
     * @param firstName the first name of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.pieChart/{studentId}")
    @Produces({"application/json"})
    public String pieChart(@PathParam("studentId") String studentId) {
        // although student ID is not necessary for this requirement, this parameter can be used as logging.  
        System.out.println("Student ID: " + studentId + " request pie chart data of favourite unit.");
        String sql = "select coursename, count(*) from profile p, course c where p.favourite_unit = c.course_id GROUP BY favourite_unit ";
        Query query = em.createNativeQuery(sql);
        List<Object[]> result = query.getResultList();
        int total = 0;
        int records = 0;
        // get the total number
        for(int i = 0; i < result.size(); i++) {
            Object[] object = result.get(i);
            total += Float.parseFloat(object[1].toString());
            ++records;
        }
        JsonBuilderFactory f = Json.createBuilderFactory(null);
        JsonObjectBuilder json = f.createObjectBuilder();
        json.add("records", records);
        JsonArrayBuilder arrayBuilder = f.createArrayBuilder();
        for(int i = 0; i < result.size(); i++) {
            Object[] object = result.get(i);
            arrayBuilder.add(object[0].toString());
            arrayBuilder.add(String.valueOf(Float.parseFloat(object[1].toString()) * 100 / total ));
        }
        json.add("data", arrayBuilder);
        return json.build().toString();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param firstName the first name of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByFirstName/{firstName}")
    @Produces({"application/json"})
    public List<Profile> findByFirstName(@PathParam("firstName") String firstName) {
        Query query = em.createNamedQuery("Profile.findByFirstName");
        query.setParameter("firstName", firstName);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param surName the surname of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findBySurName/{surName}")
    @Produces({"application/json"})
    public List<Profile> findBySurName(@PathParam("surName") String surName) {
        Query query = em.createNamedQuery("Profile.findBySurName");
        query.setParameter("surName", surName);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param surName the surname of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByDoB/{doB}")
    @Produces({"application/json"})
    public List<Profile> findByDoB(@PathParam("doB") Timestamp doB) {
        Query query = em.createNamedQuery("Profile.findByDoB");
        query.setParameter("doB", doB);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param gender the gender of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByGender/{gender}")
    @Produces({"application/json"})
    public List<Profile> findByGender(@PathParam("gender") String gender) {
        Query query = em.createNamedQuery("Profile.findByGender");
        query.setParameter("gender", gender);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param address the address of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByAddress/{address}")
    @Produces({"application/json"})
    public List<Profile> findByAddress(@PathParam("address") String address) {
        Query query = em.createNamedQuery("Profile.findByAddress");
        query.setParameter("address", address);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param suburb the suburb of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findBySuburb/{suburb}")
    @Produces({"application/json"})
    public List<Profile> findBySuburb(@PathParam("suburb") String suburb) {
        Query query = em.createNamedQuery("Profile.findBySuburb");
        query.setParameter("suburb", suburb);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param nationality the nationality of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByNationality/{nationality}")
    @Produces({"application/json"})
    public List<Profile> findByNationality(@PathParam("nationality") String nationality) {
        Query query = em.createNamedQuery("Profile.findByNationality");
        query.setParameter("nationality", nationality);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param nativeLanguage the native language of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByNativeLanguage/{nativeLanguage}")
    @Produces({"application/json"})
    public List<Profile> findByNativeLanguage(@PathParam("nativeLanguage") String nativeLanguage) {
        Query query = em.createNamedQuery("Profile.findByNativeLanguage");
        query.setParameter("nativeLanguage", nativeLanguage);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param favouriteMovie the favourite movie of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByFavouriteMovie/{favouriteMovie}")
    @Produces({"application/json"})
    public List<Profile> findByFavouriteMovie(@PathParam("favouriteMovie") String favouriteMovie) {
        Query query = em.createNamedQuery("Profile.findByFavouriteMovie");
        query.setParameter("favouriteMovie", favouriteMovie);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param favouriteSport the favourite sport of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByFavouriteSport/{favouriteSport}")
    @Produces({"application/json"})
    public List<Profile> findByFavouriteSport(@PathParam("favouriteSport") String favouriteSport) {
        Query query = em.createNamedQuery("Profile.findByFavouriteSport");
        query.setParameter("favouriteSport", favouriteSport);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param favouriteUnit the favourite unit of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByFavoriteUnit/{favouriteUnit}")
    @Produces({"application/json"})
    public List<Profile> findByFavoriteUnit(@PathParam("favouriteUnit") Integer favouriteUnit) {
        Query query = em.createNamedQuery("Profile.findByFavoriteUnit");
        query.setParameter("favouriteUnit", favouriteUnit);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param surName the surname of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByCurrentJob/{currentJob}")
    @Produces({"application/json"})
    public List<Profile> findByCurrentJob(@PathParam("currentJob") String CurrentJob) {
        Query query = em.createNamedQuery("Profile.findByCurrentJob");
        query.setParameter("currentJob", CurrentJob);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param surName the surname of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByMonashEmail/{monashEmail}")
    @Produces({"application/json"})
    public List<Profile> findByMonashEmail(@PathParam("monashEmail") String MonashEmail) {
        Query query = em.createNamedQuery("Profile.findByMonashEmail");
        query.setParameter("monashEmail", MonashEmail);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param surName the surname of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByEmailPassword/{emailPassword}")
    @Produces({"application/json"})
    public List<Profile> findByEmailPassword(@PathParam("emailPassword") String emailPassword) {
        Query query = em.createNamedQuery("Profile.findByEmailPassword");
        query.setParameter("emailPassword", emailPassword);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param surName the surname of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByStudyMode/{studyMode}")
    @Produces({"application/json"})
    public List<Profile> findByStudyMode(@PathParam("studyMode") String studyMode) {
        Query query = em.createNamedQuery("Profile.findByStudyMode");
        query.setParameter("studyMode", studyMode);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-1)
     *
     * @param surName the surname of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findBySubscriptionDatetime/{subscriptionDatetime}")
    @Produces({"application/json"})
    public List<Profile> findBySubscriptionDatetime(@PathParam("subscriptionDatetime") Timestamp subscriptionDatetime) {
        Query query = em.createNamedQuery("Profile.findBySubscriptionDatetime");
        query.setParameter("subscriptionDatetime", subscriptionDatetime);
        return query.getResultList();
    }

    /**
     * Assigment 1 task 2 b)-2) Dynamic query for profile, choose first_name &
     * sur_name to query the table;
     *
     * @param firstName the first name of student
     * @param surName the surname of student
     * @return student information with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByFirstNameANDSurName/{firstName}/{surName}")
    @Produces({"application/json"})
    public List<Profile> findByFirstNameANDSurName(@PathParam("firstName") String firstName, @PathParam("surName") String surName) {
        TypedQuery<Profile> q = em.createQuery("SELECT p FROM Profile p WHERE p.firstName = :firstName AND p.surName = :surName", Profile.class);
        q.setParameter("firstName", firstName);
        q.setParameter("surName", surName);
        return q.getResultList();
    }

    /**
     * Assigment 1 task 3 c)
     *
     * @param studentId student ID
     * @param attribute1 the first query attribute of student
     * @param attribute2 the second query attribute of student
     * @param attribute3 the third query attribute of student
     * @return a list of students (to be considered as future friends) that
     * exactly match these three criteria with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByOptionalAttributes/{studentId}/{attribute1}/{attribute2}/{attribute3}")
    @Produces({"application/json"})
    public List<Profile> findByOptionalAttributes(@PathParam("studentId") Integer studentId,
            @PathParam("attribute1") String attribute1, @PathParam("attribute2") String attribute2, @PathParam("attribute3") String attribute3) {
        StringBuilder s = new StringBuilder();
        if (studentId != null && !"".equals(studentId)) {
            s.append(" and pr.studentId = :studentId");
        } else {
            return null;
        }
        s.append(" and p.").append(attribute1).append(" =pr.").append(attribute1).append(" and p.").append(attribute2).append(" =pr.").append(attribute2).append(" and p.").append(attribute3).append(" =pr.").append(attribute3);
        TypedQuery<Profile> q = em.createQuery("SELECT p FROM Profile p, Profile pr WHERE 1 = 1" + s.toString(), Profile.class);
        q.setParameter("studentId", studentId);
        return q.getResultList();
    }

    /**
     * Assigment 1 task 3 d)
     *
     * @param studentId student ID
     * @param attribute1 the first query attribute of student
     * @param attribute2 the second query attribute of student
     * @param attribute3 the third query attribute of student
     * @param attribute4 the fourth query attribute of student
     * @param attribute5 the fifth query attribute of student
     * @param attribute6 the sixth query attribute of student
     * @param attribute7 the seventh query attribute of student
     * @param attribute8 the eighth query attribute of student
     * @param attribute9 the ninth query attribute of student
     * @param attribute10 the tenth query attribute of student
     * @param attribute11 the eleventh query attribute of student
     * @param attribute12 the twelfth query attribute of student
     * @param attribute13 the thirteenth query attribute of student
     * @param attribute14 the fourteenth query attribute of student
     * @param attribute15 the fifteenth query attribute of student
     * @param attribute16 the sixteenth query attribute of student
     * @param attribute17 the seventeenth query attribute of student
     * @return a list of students (to be considered as future friends) that
     * exactly match these three criteria with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByAllAttributes")
    @Produces({"application/json"})
    public List<Profile> findByAllAttributes(@QueryParam("studentId") Integer studentId,
            @QueryParam("attribute1") String attribute1, @QueryParam("attribute2") String attribute2,
            @QueryParam("attribute3") String attribute3, @QueryParam("attribute4") String attribute4,
            @QueryParam("attribute5") String attribute5, @QueryParam("attribute6") String attribute6,
            @QueryParam("attribute7") String attribute7, @QueryParam("attribute8") String attribute8,
            @QueryParam("attribute9") String attribute9, @QueryParam("attribute10") String attribute10,
            @QueryParam("attribute11") String attribute11, @QueryParam("attribute12") String attribute12,
            @QueryParam("attribute13") String attribute13, @QueryParam("attribute14") String attribute14,
            @QueryParam("attribute15") String attribute15, @QueryParam("attribute16") String attribute16,
            @QueryParam("attribute17") String attribute17) {
        StringBuilder s = new StringBuilder();
        String ss = "";
        if (studentId == null || "".equals(studentId)) {
            return null;
        } else {
            ss = " and pr.studentId = :studentId";
            s.append(ss);
        }
        if (attribute1 != null && !"".equals(attribute1)) {
            s.append(" and p.").append(attribute1).append(" =pr.").append(attribute1);
        }
        if (attribute2 != null && !"".equals(attribute2)) {
            s.append(" and p.").append(attribute2).append(" =pr.").append(attribute2);
        }
        if (attribute3 != null && !"".equals(attribute3)) {
            s.append(" and p.").append(attribute3).append(" =pr.").append(attribute3);
        }
        if (attribute4 != null && !"".equals(attribute4)) {
            s.append(" and p.").append(attribute4).append(" =pr.").append(attribute4);
        }
        if (attribute5 != null && !"".equals(attribute5)) {
            s.append(" and p.").append(attribute5).append(" =pr.").append(attribute5);
        }
        if (attribute6 != null && !"".equals(attribute6)) {
            s.append(" and p.").append(attribute6).append(" =pr.").append(attribute6);
        }
        if (attribute7 != null && !"".equals(attribute7)) {
            s.append(" and p.").append(attribute7).append(" =pr.").append(attribute7);
        }
        if (attribute8 != null && !"".equals(attribute8)) {
            s.append(" and p.").append(attribute8).append(" =pr.").append(attribute8);
        }
        if (attribute9 != null && !"".equals(attribute9)) {
            s.append(" and p.").append(attribute9).append(" =pr.").append(attribute9);
        }
        if (attribute10 != null && !"".equals(attribute10)) {
            s.append(" and p.").append(attribute10).append(" =pr.").append(attribute10);
        }
        if (attribute11 != null && !"".equals(attribute11)) {
            s.append(" and p.").append(attribute11).append(" =pr.").append(attribute11);
        }
        if (attribute12 != null && !"".equals(attribute12)) {
            s.append(" and p.").append(attribute12).append(" =pr.").append(attribute12);
        }
        if (attribute13 != null && !"".equals(attribute13)) {
            s.append(" and p.").append(attribute13).append(" =pr.").append(attribute13);
        }
        if (attribute14 != null && !"".equals(attribute14)) {
            s.append(" and p.").append(attribute14).append(" =pr.").append(attribute14);
        }
        if (attribute15 != null && !"".equals(attribute15)) {
            s.append(" and p.").append(attribute15).append(" =pr.").append(attribute15);
        }
        if (attribute16 != null && !"".equals(attribute16)) {
            s.append(" and p.").append(attribute16).append(" =pr.").append(attribute16);
        }
        if (attribute17 != null && !"".equals(attribute17)) {
            s.append(" and p.").append(attribute17).append(" =pr.").append(attribute17);
        }

        if (s.toString().length() == ss.length()) {
            return null;
        }
        s.append(" and p.studentId <> pr.studentId");
        TypedQuery<Profile> q = em.createQuery("SELECT p FROM Profile p, Profile pr WHERE 1 = 1" + s.toString(), Profile.class);
        q.setParameter("studentId", studentId);
        return q.getResultList();
    }

    /**
     * Assigment 1 task 3 e)
     *
     * @param
     * @return a list of all the favourite units in the Profile table and their
     * frequency with format of JSON
     * @since 1.0
     */
    @GET
    @Path("Profile.findByFavourite")
    @Produces({"application/json"})
    public List<FavouriteUnit> findByFavourite() {
        Query q = em.createNativeQuery("SELECT c.course_id, c.coursename, COUNT(p.favourite_unit) FROM Profile p join Course c on p.favourite_unit = c.course_id GROUP BY p.favourite_unit");
        List<Object[]> data = q.getResultList();
        List<FavouriteUnit> result = new ArrayList<>();
        for (Object[] objects : data) {
            FavouriteUnit fu = new FavouriteUnit();
            fu.setCourseId(Integer.parseInt(objects[0].toString()));
            fu.setCourseName(objects[1].toString());
            fu.setFrequency(Integer.parseInt(objects[2].toString()));
            result.add(fu);
        }
        return result;
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

}
