/*
 * @(#)Profile.java        1.0 2017/03/25
 *
 * Copyright (c) 2017-2017 Binary Team, Monash University.
 * Public College Building No.7, No.377 Linquan Street, 
 * Dushu Lake Science and Education Innovation Zone, Industrial Park, Suzhou, China. 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Binary Team,
 * Monash University. You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement 
 * you entered into with Binary Team.
 */
package edu.monash.friendfinder.pojo;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 * 
 * @author      lotus
 * @author      Binary Team
 * @version     1.0 25 Mar 2017
 * @since       1.0
 */
@Entity
@Table(name = "profile")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Profile.findAll", query = "SELECT p FROM Profile p")
    , @NamedQuery(name = "Profile.findByStudentId", query = "SELECT p FROM Profile p WHERE p.studentId = :studentId")
    , @NamedQuery(name = "Profile.findByFirstName", query = "SELECT p FROM Profile p WHERE p.firstName = :firstName")
    , @NamedQuery(name = "Profile.findBySurName", query = "SELECT p FROM Profile p WHERE p.surName = :surName")
    , @NamedQuery(name = "Profile.findByDoB", query = "SELECT p FROM Profile p WHERE p.doB = :doB")
    , @NamedQuery(name = "Profile.findByGender", query = "SELECT p FROM Profile p WHERE p.gender = :gender")
    , @NamedQuery(name = "Profile.findByAddress", query = "SELECT p FROM Profile p WHERE p.address = :address")
    , @NamedQuery(name = "Profile.findBySuburb", query = "SELECT p FROM Profile p WHERE p.suburb = :suburb")
    , @NamedQuery(name = "Profile.findByNationality", query = "SELECT p FROM Profile p WHERE p.nationality = :nationality")
    , @NamedQuery(name = "Profile.findByNativeLanguage", query = "SELECT p FROM Profile p WHERE p.nativeLanguage = :nativeLanguage")
    , @NamedQuery(name = "Profile.findByFavouriteMovie", query = "SELECT p FROM Profile p WHERE p.favouriteMovie = :favouriteMovie")
    , @NamedQuery(name = "Profile.findByFavouriteSport", query = "SELECT p FROM Profile p WHERE p.favouriteSport = :favouriteSport")
    , @NamedQuery(name = "Profile.findByFavoriteUnit", query = "SELECT p FROM Profile p WHERE p.favouriteUnit.courseId = :favouriteUnit")
    , @NamedQuery(name = "Profile.findByCurrentJob", query = "SELECT p FROM Profile p WHERE p.currentJob = :currentJob")
    , @NamedQuery(name = "Profile.findByMonashEmail", query = "SELECT p FROM Profile p WHERE p.monashEmail = :monashEmail")
    , @NamedQuery(name = "Profile.findByPassword", query = "SELECT p FROM Profile p WHERE p.password = :password")
    , @NamedQuery(name = "Profile.findByStudyMode", query = "SELECT p FROM Profile p WHERE p.studyMode = :studyMode")
    , @NamedQuery(name = "Profile.findBySubscriptionDatetime", query = "SELECT p FROM Profile p WHERE p.subscriptionDatetime = :subscriptionDatetime")})
public class Profile implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "student_id")
    private Integer studentId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "first_name")
    private String firstName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "sur_name")
    private String surName;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DoB")
    @Temporal(TemporalType.TIMESTAMP)
    private Date doB;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "gender")
    private String gender;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "address")
    private String address;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "suburb")
    private String suburb;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "nationality")
    private String nationality;
    @Size(max = 255)
    @Column(name = "native_language")
    private String nativeLanguage;
    @Size(max = 255)
    @Column(name = "favourite_movie")
    private String favouriteMovie;
    @Size(max = 255)
    @Column(name = "favourite_sport")
    private String favouriteSport;
    @Size(max = 255)
    @Column(name = "current_job")
    private String currentJob;
    @Size(max = 255)
    @Column(name = "monash_email")
    private String monashEmail;
    @Size(max = 255)
    @Column(name = "s_password")
    private String password;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "study_mode")
    private String studyMode;
    @Column(name = "subscription_datetime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date subscriptionDatetime;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId")
    private Collection<Friendship> friendshipCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "friendId")
    private Collection<Friendship> friendshipCollection1;
    @OneToMany(mappedBy = "studentId")
    private Collection<SlecetedCourse> slecetedcourseCollection;
    @JoinColumn(name = "favourite_unit", referencedColumnName = "course_id")
    @ManyToOne
    private Course favouriteUnit;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "studentId")
    private Collection<Location> locationCollection;

    public Profile() {
    }

    public Profile(Integer studentId) {
        this.studentId = studentId;
    }

    public Profile(Integer studentId, String firstName, String surName, Date doB, String gender, String address, String suburb, String nationality, String studyMode) {
        this.studentId = studentId;
        this.firstName = firstName;
        this.surName = surName;
        this.doB = doB;
        this.gender = gender;
        this.address = address;
        this.suburb = suburb;
        this.nationality = nationality;
        this.studyMode = studyMode;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSurName() {
        return surName;
    }

    public void setSurName(String surName) {
        this.surName = surName;
    }

    public Date getDoB() {
        return doB;
    }

    public void setDoB(Date doB) {
        this.doB = doB;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSuburb() {
        return suburb;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getNativeLanguage() {
        return nativeLanguage;
    }

    public void setNativeLanguage(String nativeLanguage) {
        this.nativeLanguage = nativeLanguage;
    }

    public String getFavouriteMovie() {
        return favouriteMovie;
    }

    public void setFavouriteMovie(String favouriteMovie) {
        this.favouriteMovie = favouriteMovie;
    }

    public String getFavouriteSport() {
        return favouriteSport;
    }

    public void setFavouriteSport(String favouriteSport) {
        this.favouriteSport = favouriteSport;
    }

    public String getCurrentJob() {
        return currentJob;
    }

    public void setCurrentJob(String currentJob) {
        this.currentJob = currentJob;
    }

    public String getMonashEmail() {
        return monashEmail;
    }

    public void setMonashEmail(String monashEmail) {
        this.monashEmail = monashEmail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStudyMode() {
        return studyMode;
    }

    public void setStudyMode(String studyMode) {
        this.studyMode = studyMode;
    }

    public Date getSubscriptionDatetime() {
        return subscriptionDatetime;
    }

    public void setSubscriptionDatetime(Date subscriptionDatetime) {
        this.subscriptionDatetime = subscriptionDatetime;
    }

    @XmlTransient
    public Collection<Friendship> getFriendshipCollection() {
        return friendshipCollection;
    }

    public void setFriendshipCollection(Collection<Friendship> friendshipCollection) {
        this.friendshipCollection = friendshipCollection;
    }

    @XmlTransient
    public Collection<Friendship> getFriendshipCollection1() {
        return friendshipCollection1;
    }

    public void setFriendshipCollection1(Collection<Friendship> friendshipCollection1) {
        this.friendshipCollection1 = friendshipCollection1;
    }

    @XmlTransient
    public Collection<SlecetedCourse> getSlecetedcourseCollection() {
        return slecetedcourseCollection;
    }

    public void setSlecetedcourseCollection(Collection<SlecetedCourse> slecetedcourseCollection) {
        this.slecetedcourseCollection = slecetedcourseCollection;
    }

    public Course getFavouriteUnit() {
        return favouriteUnit;
    }

    public void setFavouriteUnit(Course favouriteUnit) {
        this.favouriteUnit = favouriteUnit;
    }

    @XmlTransient
    public Collection<Location> getLocationCollection() {
        return locationCollection;
    }

    public void setLocationCollection(Collection<Location> locationCollection) {
        this.locationCollection = locationCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (studentId != null ? studentId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Profile)) {
            return false;
        }
        Profile other = (Profile) object;
        if ((this.studentId == null && other.studentId != null) || (this.studentId != null && !this.studentId.equals(other.studentId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "MonashFriendFinder.Profile[ studentId=" + studentId + " ]";
    }
    
}
