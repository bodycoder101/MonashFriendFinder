/*
 * @(#)LocationCount.java        1.0 2017/03/25
 *
 * Copyright (c) 2017-2017 Binary Team, Monash University.
 * Public College Building No.7, No.377 Linquan Street, 
 * Dushu Lake Science and Education Innovation Zone, Industrial Park, Suzhou, China. 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Binary Team,
 * Monash University. You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement 
 * you entered into with Binary Team.
 */
package edu.monash.friendfinder.pojo;

/**
 * 
 * @author      lotus
 * @author      Binary Team
 * @version     1.0 25 Mar 2017
 * @since       1.0
 */
public class LocationCount {
    private String locationName;
    private String count;

    public LocationCount(){
        
    }

    public LocationCount(String locationName, String count) {
        this.locationName = locationName;
        this.count = count;
    }
    
    /**
     * @return the locationName
     */
    public String getLocationName() {
        return locationName;
    }

    /**
     * @param locationName the locationName to set
     */
    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    /**
     * @return the count
     */
    public String getCount() {
        return count;
    }

    /**
     * @param count the count to set
     */
    public void setCount(String count) {
        this.count = count;
    }
    
    
}
