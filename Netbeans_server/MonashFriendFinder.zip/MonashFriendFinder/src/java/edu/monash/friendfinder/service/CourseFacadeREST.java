/*
 * @(#)CourseFacadeREST.java        1.0 2017/03/25
 *
 * Copyright (c) 2017-2017 Binary Team, Monash University.
 * Public College Building No.7, No.377 Linquan Street, 
 * Dushu Lake Science and Education Innovation Zone, Industrial Park, Suzhou, China. 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Binary Team,
 * Monash University. You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement 
 * you entered into with Binary Team.
 */
package edu.monash.friendfinder.service;

import edu.monash.friendfinder.pojo.Course;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * 
 * @author      lotus
 * @author      Binary Team
 * @version     1.0 25 Mar 2017
 * @since       1.0
 */
@Stateless
@Path("monashfriendfinder.course")
public class CourseFacadeREST extends AbstractFacade<Course> {

    @PersistenceContext(unitName = "MonashFriendFinderPU")
    private EntityManager em;

    public CourseFacadeREST() {
        super(Course.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Course entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Course entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Course find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Path("findAll")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Course> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Course> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }
    
    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param courseId    course ID 
     * @return            course information with format of JSON
     * @since             1.0
     */
    @GET
    @Path("findByCourseId/{courseId}")
    @Produces({"application/json"})
    public List<Course> findByCourseId(@PathParam("courseId") Integer courseId) {
        Query query = em.createNamedQuery("Course.findByCourseId");
        query.setParameter("courseId", courseId);
        return query.getResultList();
    }
    
    /** 
     * Assigment 1 task 2 b)-1)
     *
     * @param courseName   course name 
     * @return             course information with format of JSON
     * @since              1.0
     */
    @GET
    @Path("findByCoursename/{coursename}")
    @Produces({"application/json"})
    public List<Course> findByCoursename(@PathParam("coursename") String courseName) {
        Query query = em.createNamedQuery("Course.findByCoursename");
        query.setParameter("coursename", courseName);
        return query.getResultList();
    }
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
