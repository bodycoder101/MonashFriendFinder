package edu.monash.monashfriendfinder.pojo;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 02/05/2017
 * Time: 21:03
 * Place: SEU
 */


public class GoogleSearchIdentity {
    /**
     * https://developers.google.com/custom-search/json-api/v1/reference/cse/list
     */

    // Unique identifier for the type of current object. For this API, it is customsearch#search.
    private String kind;
    // The OpenSearch URL element that defines the template for this API.
    private Object url;

    /**
     * queries
     */
    // A description of the query.
    private String title;
    // Estimated number of total search results. May not be accurate.
    private Long totalResults;
    // The search terms entered by the user.
    private String searchTerms;

    /**
     * image
     */
    // A URL pointing to the webpage hosting the image.
    private String contextLink;
    // The height of the image, in pixels.
    private Integer height;
    // The width of the image, in pixels.
    private Integer width;
    // The size of the image, in pixels.
    private Integer size;
    // A URL to the thumbnail image.
    private String thumbnailLink;
    // The height of the thumbnail image, in pixels.
    private Integer thumbnailHeight;
    // The width of the thumbnail image, in pixels.
    private Integer thumbnailWidth;

    public GoogleSearchIdentity() {
    }

    public GoogleSearchIdentity(String kind, Object url, String title, Long totalResults, String searchTerms, String contextLink, Integer height, Integer width, Integer size, String thumbnailLink, Integer thumbnailHeight, Integer thumbnailWidth) {
        this.kind = kind;
        this.url = url;
        this.title = title;
        this.totalResults = totalResults;
        this.searchTerms = searchTerms;
        this.contextLink = contextLink;
        this.height = height;
        this.width = width;
        this.size = size;
        this.thumbnailLink = thumbnailLink;
        this.thumbnailHeight = thumbnailHeight;
        this.thumbnailWidth = thumbnailWidth;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public Object getUrl() {
        return url;
    }

    public void setUrl(Object url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(Long totalResults) {
        this.totalResults = totalResults;
    }

    public String getSearchTerms() {
        return searchTerms;
    }

    public void setSearchTerms(String searchTerms) {
        this.searchTerms = searchTerms;
    }

    public String getContextLink() {
        return contextLink;
    }

    public void setContextLink(String contextLink) {
        this.contextLink = contextLink;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public String getThumbnailLink() {
        return thumbnailLink;
    }

    public void setThumbnailLink(String thumbnailLink) {
        this.thumbnailLink = thumbnailLink;
    }

    public Integer getThumbnailHeight() {
        return thumbnailHeight;
    }

    public void setThumbnailHeight(Integer thumbnailHeight) {
        this.thumbnailHeight = thumbnailHeight;
    }

    public Integer getThumbnailWidth() {
        return thumbnailWidth;
    }

    public void setThumbnailWidth(Integer thumbnailWidth) {
        this.thumbnailWidth = thumbnailWidth;
    }
}
