package edu.monash.monashfriendfinder.view;

/**
 * Created with Android Studio.
 * User: Bodycoder
 * Date: 06/05/2017
 */

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import edu.monash.monashfriendfinder.R;
import edu.monash.monashfriendfinder.db.DatabaseHelper;
import edu.monash.monashfriendfinder.pojo.C;
import edu.monash.monashfriendfinder.pojo.Profile;
import edu.monash.monashfriendfinder.util.HashPassword;
import edu.monash.monashfriendfinder.util.ToastUtil;


public class RegisterActivity extends AppCompatActivity {
    private final String methodPath = "monashfriendfinder.profile/Profile.register/";

    private EditText et_first_name;
    private EditText et_sur_name;
    private CalendarView calendarView;
    private RadioGroup radioGroup_display;
    private EditText et_address;
    private Spinner s_suburb;
    private Spinner s_nationality;
    private Spinner s_native_language;
    private EditText et_favourite_movie;
    private Spinner s_favourite_unit;
    private Spinner s_sport;
    private EditText et_job;
    private EditText et_email;
    private EditText et_password;
    private Spinner s_study_mode;
    private Button btn_register;
    private Button btn_cancel;

    public Handler handler;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    private String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        et_first_name = (EditText) findViewById(R.id.et_first_name);
        et_sur_name = (EditText) findViewById(R.id.et_sur_name);
        calendarView = (CalendarView) findViewById(R.id.calendarView);
        radioGroup_display = (RadioGroup) findViewById(R.id.radioGroup_display);
        et_address = (EditText) findViewById(R.id.et_address);
        s_suburb = (Spinner) findViewById(R.id.s_suburb);
        s_nationality = (Spinner) findViewById(R.id.s_nationality);
        s_native_language = (Spinner) findViewById(R.id.s_native_language);
        et_favourite_movie = (EditText) findViewById(R.id.et_favourite_movie);
        s_favourite_unit = (Spinner) findViewById(R.id.s_favourite_unit);
        s_sport = (Spinner) findViewById(R.id.s_sport);
        et_job = (EditText) findViewById(R.id.et_job);
        et_email = (EditText) findViewById(R.id.et_email);
        et_password = (EditText) findViewById(R.id.et_password);
        s_study_mode = (Spinner) findViewById(R.id.s_study_mode);
        btn_register = (Button) findViewById(R.id.btn_register);
        btn_cancel = (Button) findViewById(R.id.btn_cancel);



        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                date = year + "-" + month + "-" + dayOfMonth;
            }
        });



        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Profile profile = new Profile();
                String password="";
                profile.setFirstName(et_first_name.getText().toString());
                profile.setSurName(et_sur_name.getText().toString());
                // CalendarView
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                if (date == null || "".equals(date)) {
                    profile.setDoB(sdf.format(new Date()));
                } else {
                    profile.setDoB(date);
                }
                RadioButton radioButton = (RadioButton) findViewById(radioGroup_display.getCheckedRadioButtonId());
                profile.setGender(radioButton.getText().toString());
                profile.setAddress(et_address.getText().toString());
                // Spinner
                profile.setSuburb(s_suburb.getSelectedItem().toString());
                profile.setNationality(s_nationality.getSelectedItem().toString());
                profile.setNativeLanguage(s_native_language.getSelectedItem().toString());
                profile.setFavouriteMovie(et_favourite_movie.getText().toString());
                profile.setFavouriteSport(s_sport.getSelectedItem().toString());
                profile.setFavouriteUnit(s_favourite_unit.getSelectedItem().toString() + "&" + (s_favourite_unit.getSelectedItemId() + 1));
                profile.setCurrentJob(et_job.getText().toString());
                profile.setMonashEmail(et_email.getText().toString());

                password = et_password.getText().toString();
                try {
                    profile.setPassword(HashPassword.sha1(password));
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }


                profile.setStudyMode(s_study_mode.getSelectedItem().toString());
                profile.setSubscriptionDatetime(sdf.format(new Date()));
                Thread register = new Thread(new Register(profile));
                register.start();
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                // Login
                if (msg.what == 0x113) {
                    Bundle bundle = msg.getData();
                    String login = bundle.getString("login");
                    if ("true".equals(login)) {
                        sharedPreferences = getSharedPreferences("MonashFriendFinderShared", MODE_WORLD_WRITEABLE);
                        editor = sharedPreferences.edit();
                        editor.putString("hasLogin", "true");
                        editor.commit();
                        Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                        intent.putExtra("profile", bundle);
                        startActivity(intent);
                        Log.e("Login Result", bundle.getString("login"));
                    }
                }
            }
        };

    }

    private class Register implements Runnable {
        private Profile profile;

        public Register(Profile profile) {
            this.profile = profile;
        }

        @Override
        public void run() {
            Looper.prepare();

            Bundle bundle = new Bundle();
            URL url = null;
            //open the connection
            HttpURLConnection conn = null;
            StringBuilder searchUrl = new StringBuilder(C.SERVER_BASE_URI)
                    .append(methodPath)
                    .append(profile.getFirstName()).append("/")
                    .append(profile.getSurName()).append("/")
                    .append(profile.getDoB()).append("/")
                    .append(profile.getGender()).append("/")
                    .append(profile.getAddress()).append("/")
                    .append(profile.getSuburb()).append("/")
                    .append(profile.getNationality()).append("/")
                    .append(profile.getNativeLanguage()).append("/")
                    .append(profile.getFavouriteMovie()).append("/")
                    .append(profile.getFavouriteUnit().split("&")[1]).append("/")
                    .append(profile.getFavouriteSport()).append("/")
                    .append(profile.getCurrentJob()).append("/")
                    .append(profile.getMonashEmail()).append("/")
                    .append(profile.getPassword()).append("/")
                    .append(profile.getStudyMode()).append("/")
                    .append(profile.getSubscriptionDatetime()).append("/");

            //Making HTTP request
            try {
                url = new URL(searchUrl.toString());
                //open the connection
                conn = (HttpURLConnection) url.openConnection();
                //set the timeout
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000); //set the connection method to GET
                conn.setRequestMethod("POST");
                //add http headers to set your response type to json
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json"); //Read the response
                Scanner inStream = new Scanner(conn.getInputStream()); //read the input steream and store it as string
                StringBuilder textResult = new StringBuilder();
                while (inStream.hasNextLine()) {
                    textResult.append(inStream.nextLine());
                }
                if ("exists".equals(textResult.toString())) {
                    ToastUtil.show(getApplicationContext(), "This account has registered.");
                } else if ("false".equals(textResult.toString())) {
                    ToastUtil.show(getApplicationContext(), "Register failed.");
                } else {
                    // if the register operation success, save the information to local database
                    DatabaseHelper db = new DatabaseHelper(getApplicationContext(), "MonashFriendFinder.db", 1);
                    SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();

                    String[] record = new String[17];
                    record[0] = textResult.toString();
                    record[1] = profile.getFirstName();
                    record[2] = profile.getSurName();
                    // only save the year, month, day
                    record[3] = profile.getDoB();
                    record[4] = profile.getGender();
                    record[5] = profile.getAddress();
                    record[6] = profile.getSuburb();
                    record[7] = profile.getNationality();
                    record[8] = profile.getNativeLanguage();
                    record[9] = profile.getFavouriteMovie();
                    String[] unit = profile.getFavouriteUnit().split("&");
                    // course ID
                    record[10] = unit[1];
                    // course name
                    record[11] = unit[0];
                    record[12] = profile.getFavouriteSport();
                    record[13] = profile.getMonashEmail();
                    record[14] = profile.getPassword();
                    record[15] = profile.getStudyMode();
                    record[16] = profile.getSubscriptionDatetime();
                    // save profile
                    sqLiteDatabase.execSQL("insert into profile values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", record);
                    bundle.putString("login", "true");
                    bundle.putString("studentId", textResult.toString());
                    bundle.putString("studentName", record[1] + " " + record[2]);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
                Log.e("Register", "failed.");
            } catch (ProtocolException e) {
                e.printStackTrace();
                Log.e("Register", "failed.");
            } catch (IOException e) {
                e.printStackTrace();
                Log.e("Register", "failed.");
            } finally {
                conn.disconnect();
            }
            Message message = new Message();
            // Login
            message.what = 0x113;
            message.setData(bundle);
            handler.sendMessage(message);
            Looper.loop();
        }
    }
}
