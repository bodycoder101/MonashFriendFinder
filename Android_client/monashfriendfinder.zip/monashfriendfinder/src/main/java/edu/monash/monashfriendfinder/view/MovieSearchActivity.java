package edu.monash.monashfriendfinder.view;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.Nullable;
import android.view.KeyEvent;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import edu.monash.monashfriendfinder.R;
import edu.monash.monashfriendfinder.pojo.C;
import edu.monash.monashfriendfinder.pojo.SearchViewer;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 02/05/2017
 * Time: 20:12
 * Place: SEU
 */


public class MovieSearchActivity extends Activity {
    private SearchViewer searchViewer;

    private TextView name;
    private TextView contentrating;
    private TextView duration;
    private TextView genre;
    private TextView datepublished;
    private TextView trailer;
    private TextView description;
    private TextView headline;
    private TextView provider;
    private TextView contentUrl;
    private TextView awards;
    private TextView thumbnailurl;
    private TextView keywords;

    private ImageView movieImage;
    public Handler handler;

    private Bundle bundle;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_search);

        name = (TextView) findViewById(R.id.movieSearchName);
        contentrating = (TextView) findViewById(R.id.movieSearchContentRating);
        duration = (TextView) findViewById(R.id.movieSearchDuration);
        genre = (TextView) findViewById(R.id.movieSearchGenre);
        datepublished = (TextView) findViewById(R.id.movieSearchDatePublished);
        trailer = (TextView) findViewById(R.id.movieSearchTrailer);
        description = (TextView) findViewById(R.id.movieSearchDescription);
        headline = (TextView) findViewById(R.id.movieSearchHeadline);
        provider = (TextView) findViewById(R.id.movieSearchProvider);
        contentUrl = (TextView) findViewById(R.id.movieSearchURL);
        awards = (TextView) findViewById(R.id.movieSearchAwards);
        thumbnailurl = (TextView) findViewById(R.id.movieSearchThumbnailurl);
        keywords = (TextView) findViewById(R.id.movieSearchKeywords);

        movieImage = (ImageView) findViewById(R.id.movieImage);

        searchViewer = (SearchViewer) findViewById(R.id.search);
        searchViewer.onActionViewExpanded();
        searchViewer.setActivated(true);
        searchViewer.clearFocus();
        searchViewer.setIconified(false);

        // read data
        Intent intent = getIntent();
        // final Bundle bundle = intent.getBundleExtra("profile");

        bundle = intent.getBundleExtra("matchedDetail");
        String movieName = bundle.getString("Movie");
        if (movieName != null && !"".equals(movieName)) {
            // set movie name
            searchViewer.setQueryHint(movieName);
            Search search = new Search(movieName);
            Thread excute = new Thread(search);
            excute.start();
        }

        searchViewer.setOnQueryTextListener(new SearchViewer.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Search search = new Search(query);
                Thread excute = new Thread(search);
                excute.start();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }

        });

        searchViewer.setOnBackPressListener(new SearchViewer.OnBackPressListener() {
            @Override
            public void backPress() {
                Intent main = new Intent(MovieSearchActivity.this, MatchedStudent.class);
                main.putExtra("matchedDetail", bundle);
                startActivity(main);
                finish();
            }
        });

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (msg.what == 0x111) {
                    Bundle bundle = msg.getData();
                    byte[] imageData = bundle.getByteArray("imageSource");
                    InputStream inputStream = new ByteArrayInputStream(imageData);
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    movieImage.setImageBitmap(bitmap);

                    name.setText(bundle.getString("name"));
                    contentrating.setText(bundle.getString("contentrating"));
                    duration.setText(bundle.getString("duration"));
                    genre.setText(bundle.getString("genre"));
                    datepublished.setText(bundle.getString("datepublished"));
                    trailer.setText(bundle.getString("trailer"));
                    description.setText(bundle.getString("description"));
                    headline.setText(bundle.getString("headline"));
                    provider.setText(bundle.getString("provider"));
                    contentUrl.setText(bundle.getString("url"));
                    awards.setText(bundle.getString("awards"));
                    thumbnailurl.setText(bundle.getString("thumbnailurl"));
                    keywords.setText(bundle.getString("keywords"));
                }
            }
        };
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent main = new Intent(MovieSearchActivity.this, MatchedStudent.class);
            main.putExtra("matchedDetail", bundle);
            startActivity(main);
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        onNavigateUp();
        Intent main = new Intent(MovieSearchActivity.this, MatchedStudent.class);
        main.putExtra("matchedDetail", bundle);
        startActivity(main);
        this.finish();
    }

    private class Search implements Runnable {
        private String keywords;
        private String searchUrl;

        public Search(String keywords) {
            this.keywords = keywords;
            searchUrl = C.GOOGLE_SEARCH_HOST + "?key=" + C.SEARCH_API_KEY + "&cx=" + C.CX + "&q=" + keywords;
        }

        @Override
        public void run() {

            Looper.prepare();

            Bundle bundle = new Bundle();
            OkHttpClient client = new OkHttpClient();

            // Create request for remote resource.
            Request request = new Request.Builder()
                    .url(searchUrl)
                    .build();

            // Execute the request and retrieve the response.
            Response response = null;
            try {
                response = client.newCall(request).execute();
                // Deserialize HTTP response to concrete type.
                JSONObject jsonObject = new JSONObject(response.body().string().toString());


                JSONObject queries = jsonObject.getJSONObject("queries");

                JSONArray searchRequest = queries.getJSONArray("request");
                JSONObject requestSearch = searchRequest.getJSONObject(0);
                bundle.putString("title", requestSearch.getString("title"));
                // identity.setTitle(temp.getString(0));
                // attribute: totalResults
                bundle.putString("totalResults", requestSearch.getString("totalResults"));
                // identity.setTotalResults(temp.getLong(2));
                // attribute: searchTerms
                bundle.putString("searchTerms", requestSearch.getString("searchTerms"));

                JSONArray items = jsonObject.getJSONArray("items");
                JSONObject itemsSearch = items.getJSONObject(0);
                JSONObject pagemap = itemsSearch.getJSONObject("pagemap");
                JSONArray movie = pagemap.getJSONArray("movie");
                JSONObject movieSearch = movie.getJSONObject(0);

                bundle.putString("name", movieSearch.getString("name"));
                bundle.putString("contentrating", movieSearch.getString("contentrating"));
                bundle.putString("duration", movieSearch.getString("duration"));
                bundle.putString("genre", movieSearch.getString("genre"));
                bundle.putString("datepublished", movieSearch.getString("datepublished"));
                bundle.putString("trailer", movieSearch.getString("trailer"));
                bundle.putString("description", movieSearch.getString("description"));
                bundle.putString("headline", movieSearch.getString("headline"));
                bundle.putString("provider", movieSearch.getString("provider"));
                bundle.putString("url", movieSearch.getString("url"));
                bundle.putString("awards", movieSearch.getString("awards"));
                bundle.putString("thumbnailurl", movieSearch.getString("thumbnailurl"));
                bundle.putString("keywords", movieSearch.getString("keywords"));

                // Image
                bundle.putString("image", movieSearch.getString("keywords"));
                URL movieImageUrl = new URL(movieSearch.getString("image"));
                HttpURLConnection httpURLConnection = (HttpURLConnection) movieImageUrl.openConnection();
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.setReadTimeout(50000);
                InputStream input = httpURLConnection.getInputStream();
                ByteArrayOutputStream outSteam = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int len = -1;
                while ((len = input.read(buffer)) != -1) {
                    outSteam.write(buffer, 0, len);
                }

                bundle.putByteArray("imageSource", outSteam.toByteArray());
                outSteam.close();
                input.close();
                Message message = new Message();
                message.what = 0x111;
                message.setData(bundle);
                handler.sendMessage(message);

            } catch (IOException e) {

                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            Looper.loop();

        }
    }
}
