package edu.monash.monashfriendfinder.view;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;

import java.text.SimpleDateFormat;
import java.util.Date;

import edu.monash.monashfriendfinder.R;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 11/05/2017
 * Time: 22:37
 * Place: SEU
 */


public class SelectLocationBarActivity extends Activity {

    private CalendarView startCalendar;
    private CalendarView endCalendar;
    private Button search;

    private Bundle bundle;

    private String startDate;
    private String endDate;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_location_bar);

        // read data
        Intent intent = getIntent();
        bundle = intent.getBundleExtra("profile");

        startCalendar = (CalendarView) findViewById(R.id.calendarViewStart);
        endCalendar = (CalendarView) findViewById(R.id.calendarViewEnd);
        search = (Button) findViewById(R.id.btn_search);

        startCalendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                startDate = year + "-" + month + "-" + dayOfMonth;
            }
        });

        endCalendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                endDate = year + "-" + month + "-" + dayOfMonth;
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectLocationBarActivity.this, BarChartActivity.class);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                if (startDate == null || "".equals(startDate)) {
                    bundle.putString("startDate", sdf.format(new Date()));
                } else {
                    bundle.putString("startDate", startDate);
                }
                if (endDate == null || "".equals(endDate)) {
                    bundle.putString("endDate", sdf.format(new Date()));
                } else {
                    bundle.putString("endDate", endDate);
                }
                intent.putExtra("profile", bundle);
                startActivity(intent);
                finish();
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent main = new Intent(SelectLocationBarActivity.this, ShowChartActivity.class);
        bundle.remove("startDate");
        bundle.remove("endDate");
        main.putExtra("profile", bundle);
        startActivity(main);
        finish();
    }

}
