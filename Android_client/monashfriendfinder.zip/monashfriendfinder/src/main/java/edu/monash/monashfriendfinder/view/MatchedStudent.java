package edu.monash.monashfriendfinder.view;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

import edu.monash.monashfriendfinder.R;
import edu.monash.monashfriendfinder.pojo.C;
import edu.monash.monashfriendfinder.util.ToastUtil;

/**
 * Created with Android Studio.
 * User: LiZhenzhen
 * Date: 11/05/2017
 */

public class MatchedStudent extends AppCompatActivity {
    private final String methodPath = "monashfriendfinder.friendship/Friendship.addFriendships/";

    private TextView te_student_id;
    private TextView te_firstName;
    private TextView te_surName;
    private TextView te_doB;
    private TextView te_gender;
    private TextView te_address;
    private TextView te_suburb;
    private TextView te_nationality;
    private TextView te_native_language;
    private TextView te_favourite_movie;
    private TextView te_favourite_unit;
    private TextView te_favourite_sport;
    private TextView te_monash_email;
    private TextView te_study_mode;
    private TextView te_subscription_datetime;
    private Button btn_save;

    private Bundle bundle;
    private Handler handler;

    private Bundle profileBundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_matched_student);

        te_student_id = (TextView) findViewById(R.id.te_student_id);
        te_firstName = (TextView) findViewById(R.id.te_firstName);
        te_surName = (TextView) findViewById(R.id.te_surName);
        te_doB = (TextView) findViewById(R.id.te_doB);
        te_gender = (TextView) findViewById(R.id.te_gender);
        te_address = (TextView) findViewById(R.id.te_address);
        te_suburb = (TextView) findViewById(R.id.te_suburb);
        te_nationality = (TextView) findViewById(R.id.te_nationality);
        te_native_language = (TextView) findViewById(R.id.te_native_language);
        te_favourite_movie = (TextView) findViewById(R.id.te_favourite_movie);
        te_favourite_unit = (TextView) findViewById(R.id.te_favourite_unit);
        te_favourite_sport = (TextView) findViewById(R.id.te_favourite_sport);
        te_monash_email = (TextView) findViewById(R.id.te_monash_email);
        te_study_mode = (TextView) findViewById(R.id.te_study_mode);
        te_subscription_datetime = (TextView) findViewById(R.id.te_subscription_datetime);
        btn_save = (Button) findViewById(R.id.btn_save);

        // read data
        Intent intent = getIntent();

        profileBundle = intent.getBundleExtra("profile");

        bundle = intent.getBundleExtra("matchedDetail");
        final String selfId = bundle.getString("SelfId");
        String json = bundle.getString("StudentDetail");

        try {
            JSONObject person = new JSONObject(json);
            te_student_id.setText(person.getString("studentId"));
            te_address.setText(person.getString("address"));
            te_doB.setText(person.getString("doB").split("T")[0]);
            te_favourite_movie.setText(person.getString("favouriteMovie"));
            te_favourite_sport.setText(person.getString("favouriteSport"));
            // favouriteUnit
            JSONObject favouriteUnit = person.getJSONObject("favouriteUnit");
            te_favourite_unit.setText(favouriteUnit.getString("coursename"));
            te_firstName.setText(person.getString("firstName"));
            te_gender.setText(person.getString("gender"));
            te_monash_email.setText(person.getString("monashEmail"));
            te_nationality.setText(person.getString("nationality"));
            te_native_language.setText(person.getString("nativeLanguage"));
            te_study_mode.setText(person.getString("studyMode"));
            te_subscription_datetime.setText(person.getString("subscriptionDatetime").split("T")[0]);
            te_suburb.setText(person.getString("suburb"));
            te_surName.setText(person.getString("surName"));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        te_favourite_movie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent movieIntent =  new Intent(MatchedStudent.this, MovieSearchActivity.class);
                String movieName = te_favourite_movie.getText().toString();
                bundle.putString("Movie", movieName);
                movieIntent.putExtra("matchedDetail", bundle);
                startActivity(movieIntent);
            }
        });

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String studentId = te_student_id.getText().toString();
                AddFriendship addFriendship = new AddFriendship(selfId, studentId);
                Thread thread = new Thread(addFriendship);
                thread.start();
            }
        });

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (msg.what == 0x118) {
                    Bundle bundle = msg.getData();
                    String result = bundle.getString("result");
                    if ("true".equals(result)) {
                        ToastUtil.show(getApplicationContext(), "Add friend succeed.");
                        Intent searchIntent = new Intent(MatchedStudent.this, SearchActivity.class);
                        searchIntent.putExtra("profile", profileBundle);
                        startActivity(searchIntent);
                        finish();
                    } else {
                        ToastUtil.show(getApplicationContext(), "Add friend failed.");
                    }
                }
            }
        };
    }

    class AddFriendship implements Runnable {
        private String selfId;
        private String studentId;

        public AddFriendship(String selfId, String studentId) {
            this.selfId = selfId;
            this.studentId = studentId;
        }

        @Override
        public void run() {
            Looper.prepare();

            Bundle bundle = new Bundle();
            //Making HTTP request
            URL url = null;
            //open the connection
            HttpURLConnection conn = null;
            try {
                String searchUrl = C.SERVER_BASE_URI + methodPath + selfId + "/" + studentId + "/";
                //Making HTTP request
                url = new URL(searchUrl);
                //open the connection
                conn = (HttpURLConnection) url.openConnection();
                //set the timeout
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000); //set the connection method to GET
                conn.setRequestMethod("POST");
                //add http headers to set your response type to json
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json"); //Read the response
                Scanner inStream = new Scanner(conn.getInputStream()); //read the input steream and store it as string
                StringBuilder textResult = new StringBuilder();
                while (inStream.hasNextLine()) {
                    textResult.append(inStream.nextLine());
                }
                if ("true".equals(textResult.toString())) {
                    bundle.putString("result", "true");
                } else {
                    bundle.putString("result", "false");
                }
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("Add friendship:", "failed.");
            } finally {
                conn.disconnect();
            }
            Message message = new Message();
            // add friendship
            message.what = 0x118;
            message.setData(bundle);
            handler.sendMessage(message);
            Looper.loop();
        }
    }
}
