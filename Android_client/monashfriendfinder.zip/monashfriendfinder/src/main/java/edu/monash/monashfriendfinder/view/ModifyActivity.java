package edu.monash.monashfriendfinder.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import edu.monash.monashfriendfinder.R;
import edu.monash.monashfriendfinder.db.DatabaseHelper;
import edu.monash.monashfriendfinder.pojo.C;
import edu.monash.monashfriendfinder.util.HashPassword;
import edu.monash.monashfriendfinder.util.ToastUtil;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 06/05/2017
 * Time: 17:18
 * Place: SEU
 */

public class ModifyActivity extends AppCompatActivity {
    //    {studentId}/{firstName}/{surName}/{doB}/{gender}/{address}/{suburb}/
//    {nationality}/{nativeLanguage}/{favouriteMovie}/{favouriteSport}/{currentJob}/{password}")
    private final String methodPath = "monashfriendfinder.profile/Profile.update/";
    private TextView te_student_id;
    private EditText et_first_name;
    private EditText et_sur_name;
    private CalendarView calendarView;
    // gender
    private RadioGroup radioGroup_display;
    private RadioButton rb_display_male;
    private RadioButton rb_display_female;

    private EditText et_address;
    private Spinner s_suburb;
    private Spinner s_nationality;
    private Spinner s_native_language;
    private EditText et_favourite_movie;
    // private Spinner s_favourite_unit;
    private Spinner s_sport;
    // private EditText et_job;
    private EditText et_password;
    // private Spinner s_study_mode;
    private Button btn_save;

    public Handler handler;

    private String date;

    DatabaseHelper db;
    SQLiteDatabase sqLiteDatabase;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);

        // get the items of suburb
        String[] mItems = getResources().getStringArray(R.array.suburb);
        // nationality
        String[] mItemsNationality = getResources().getStringArray(R.array.nationality);
        // native_language
        String[] mItemsLanguage = getResources().getStringArray(R.array.native_language);
        // sports
        String[] mItemsSports = getResources().getStringArray(R.array.sports);

        te_student_id = (TextView) findViewById(R.id.te_student_id);
        et_first_name = (EditText) findViewById(R.id.et_first_name);
        et_sur_name = (EditText) findViewById(R.id.et_sur_name);
        calendarView = (CalendarView) findViewById(R.id.calendarView);
        radioGroup_display = (RadioGroup) findViewById(R.id.radioGroup_display);
        rb_display_male = (RadioButton) findViewById(R.id.rb_display_male);
        rb_display_female = (RadioButton) findViewById(R.id.rb_display_female);

        et_address = (EditText) findViewById(R.id.et_address);
        s_suburb = (Spinner) findViewById(R.id.s_suburb);
        s_nationality = (Spinner) findViewById(R.id.s_nationality);
        s_native_language = (Spinner) findViewById(R.id.s_native_language);
        et_favourite_movie = (EditText) findViewById(R.id.et_favourite_movie);
        // s_favourite_unit = (Spinner) findViewById(R.id.s_favourite_unit);
        s_sport = (Spinner) findViewById(R.id.s_sport);
        // et_job = (EditText) findViewById(R.id.et_job);
        // et_email = (EditText) findViewById(R.id.et_email);
        et_password = (EditText) findViewById(R.id.et_password);
//        password = et_password.getText().toString();
//        try {
//            profile.setPassword(HashPassword.sha1(password));
//        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
//        }
        // s_study_mode = (Spinner) findViewById(R.id.s_study_mode);
        btn_save = (Button) findViewById(R.id.btn_save);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                date = year + "-" + month + "-" + dayOfMonth;
            }
        });

        // bind the data to spinner view
        ArrayAdapter<String> adapterSuburb = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, mItems);
        s_suburb.setAdapter(adapterSuburb);
        ArrayAdapter<String> adapterNationality = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, mItemsNationality);
        s_nationality.setAdapter(adapterNationality);
        ArrayAdapter<String> adapterLanguage = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, mItemsLanguage);
        s_native_language.setAdapter(adapterLanguage);
        ArrayAdapter<String> adapterSports = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, mItemsSports);
        s_sport.setAdapter(adapterSports);

        // read data
        Intent intent = getIntent();
        final Bundle bundle = intent.getBundleExtra("profile");
        final String studentName = bundle.getString("studentName");
        final String studentId = bundle.getString("studentId");

        // get the values[] from local database
        db = new DatabaseHelper(getApplicationContext(), "MonashFriendFinder.db", 1);
        sqLiteDatabase = db.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select student_id, first_name, sur_name, DOB, gender, address, suburb, nationality, native_language, favourite_movie, favourite_sport, s_password from profile where student_id = ?", new String[]{studentId});
        // Map<String, String> map = new HashMap<String, String>();
        while (cursor.moveToNext()) {
            // map.put("student_id", cursor.getString(0));
            te_student_id.setText(cursor.getString(0));
            // map.put("first_name", cursor.getString(1));
            et_first_name.setText(cursor.getString(1));
            // map.put("sur_name", cursor.getString(2));
            et_sur_name.setText(cursor.getString(2));
            // map.put("DOB", cursor.getString(3));
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            try {
                calendarView.setDate(sdf.parse(cursor.getString(3)).getTime());
            } catch (ParseException e) {
                e.printStackTrace();
            }

            // map.put("gender", cursor.getString(4));
            if ("M".equals(cursor.getString(4))) {
                rb_display_male.setChecked(true);
                rb_display_female.setChecked(false);
            } else {
                rb_display_female.setChecked(true);
                rb_display_male.setChecked(false);
            }

            // map.put("address", cursor.getString(5));
            et_address.setText(cursor.getString(5));
            // map.put("suburb", cursor.getString(6));
            boolean match = true;
            for (int i = 0; i < mItems.length; i++) {
                if (cursor.getString(6).equals(mItems[i])) {
                    s_suburb.setSelection(i);
                    match = false;
                    break;
                }
            }
            if (match) {
                s_suburb.setSelection(0);
                // for the next operation to use
                match = true;
            }

            // map.put("nationality", cursor.getString(7));
            for (int i = 0; i < mItemsNationality.length; i++) {
                if (cursor.getString(7).equals(mItemsNationality[i])) {
                    s_nationality.setSelection(i);
                    match = false;
                    break;
                }
            }
            if (match) {
                s_nationality.setSelection(0);
                // for the next operation to use
                match = true;
            }
            // map.put("native_language", cursor.getString(8));
            for (int i = 0; i < mItemsLanguage.length; i++) {
                if (cursor.getString(8).equals(mItemsLanguage[i])) {
                    s_native_language.setSelection(i);
                    match = false;
                    break;
                }
            }
            if (match) {
                s_native_language.setSelection(0);
                // for the next operation to use
                match = true;
            }

            // map.put("favourite_movie", cursor.getString(9));
            et_favourite_movie.setText(cursor.getString(9));
            // map.put("favourite_sport", cursor.getString(10));
            // map.put("native_language", cursor.getString(8));
            for (int i = 0; i < mItemsSports.length; i++) {
                if (cursor.getString(9).equals(mItemsSports[i])) {
                    s_sport.setSelection(i);
                    match = false;
                    break;
                }
            }
            if (match) {
                s_sport.setSelection(0);
            }

            // map.put("s_password", cursor.getString(11));
            et_password.setText(cursor.getString(11));
            // if there are more than one records, only get the first record to prevent exceptions
            break;
        }

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] values = new String[12];
                values[0] = et_first_name.getText().toString();
                values[1] = et_sur_name.getText().toString();
                // CalendarView
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                if (date == null ) {
                    values[2] = sdf.format(new Date());
                } else {
                    values[2] = date;
                }
                RadioButton radioButton = (RadioButton) findViewById(radioGroup_display.getCheckedRadioButtonId());
                values[3] = radioButton.getText().toString();
                values[4] = et_address.getText().toString();
                // Spinner
                values[5] = s_suburb.getSelectedItem().toString();
                values[6] = s_nationality.getSelectedItem().toString();
                values[7] = s_native_language.getSelectedItem().toString();
                values[8] = et_favourite_movie.getText().toString();
                values[9] = s_sport.getSelectedItem().toString();
                values[10] = et_password.getText().toString();
                values[11] = te_student_id.getText().toString();
                sqLiteDatabase.execSQL("update profile set first_name = ?, sur_name = ?, DOB = ?, gender = ?, address = ?, suburb = ?, nationality = ?, native_language = ?, favourite_movie = ?, favourite_sport = ?, s_password = ? where student_id = ?", values);
                Thread register = new Thread(new UpdateProfile(values));
                register.start();
            }
        });

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                Bundle data = msg.getData();
                // Login
                if (msg.what == 0x114) {
                    Intent intent = new Intent(ModifyActivity.this, MainActivity.class);
                    intent.putExtra("profile", data);
                    startActivity(intent);
                    Log.e("Update Result", "Succeed.");
                    finish();
                }
            }
        };

    }

    private class UpdateProfile implements Runnable {
        String[] values;

        public UpdateProfile(String[] values) {
            this.values = values;
        }

        @Override
        public void run() {
            Looper.prepare();

            String Hashcode="";
            try {
                Hashcode = HashPassword.sha1(values[10]);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            URL url = null;
            //open the connection
            HttpURLConnection conn = null;
            StringBuilder searchUrl = new StringBuilder(C.SERVER_BASE_URI)
                    .append(methodPath)
                    // put student ID in the first place
                    .append(values[11]).append("/")
                    .append(values[0]).append("/")
                    .append(values[1]).append("/")
                    .append(values[2]).append("/")
                    .append(values[3]).append("/")
                    .append(values[4]).append("/")
                    .append(values[5]).append("/")
                    .append(values[6]).append("/")
                    .append(values[7]).append("/")
                    .append(values[8]).append("/")
                    .append(values[9]).append("/")
                    .append(Hashcode).append("/");

            Bundle updateData = new Bundle();
            //Making HTTP request
            try {
                url = new URL(searchUrl.toString());
                //open the connection
                conn = (HttpURLConnection) url.openConnection();
                //set the timeout
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000); //set the connection method to GET
                conn.setRequestMethod("PUT");
                //add http headers to set your response type to json
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json"); //Read the response
                Scanner inStream = new Scanner(conn.getInputStream()); //read the input steream and store it as string
                StringBuilder textResult = new StringBuilder();
                while (inStream.hasNextLine()) {
                    textResult.append(inStream.nextLine());
                }
                if ("true".equals(textResult.toString())) {
                    // put student ID
                    updateData.putString("studentId", values[11]);
                    // put the updated student name
                    updateData.putString("studentName", values[0] + " " + values[1]);
                    ToastUtil.show(getApplicationContext(), "Update succeed.");
                } else if ("false".equals(textResult.toString())) {
                    ToastUtil.show(getApplicationContext(), "Update failed.");
                }
            } catch (ProtocolException e) {
                e.printStackTrace();
                Log.e("Register", "failed.");
            } catch (IOException e) {
                e.printStackTrace();
                Log.e("Register", "failed.");
            } finally {
                conn.disconnect();
            }
            Message message = new Message();
            message.setData(updateData);
            // update
            message.what = 0x114;
            handler.sendMessage(message);
            Looper.loop();
        }
    }

}
