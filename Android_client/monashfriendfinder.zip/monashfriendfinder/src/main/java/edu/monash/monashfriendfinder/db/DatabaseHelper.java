/**
 *
 */
package edu.monash.monashfriendfinder.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 04/05/2017
 * Time: 22:51
 * Place: SEU
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    final String CREATE_TABLE_SQL =
            // table profile
            new StringBuilder("create table profile(")
                    .append("student_id bigint unsigned NOT NULL primary key,")
                    .append("first_name varchar(10) NOT NULL,")
                    .append("sur_name varchar(10) NOT NULL,")
                    .append("DOB varchar(15) NOT NULL,")
                    .append("gender char(2) NOT NULL,")
                    .append("address varchar(50) NOT NULL,")
                    .append("suburb varchar(50) NOT NULL,")
                    .append("nationality varchar(10) NOT NULL,")
                    .append("native_language varchar(10) DEFAULT NULL,")
                    .append("favourite_movie varchar(50) DEFAULT NULL,")
                    .append("favourite_unitId bigint unsigned ,")
                    .append("favourite_unitName varchar(50) ,")
                    .append("favourite_sport varchar(50) DEFAULT NULL,")
                    .append("monash_email varchar(50) DEFAULT NULL,")
                    .append("s_password varchar(20) DEFAULT NULL,")
                    .append("study_mode char(2) NOT NULL,")
                    .append("subscription_datetime varchar(15) DEFAULT NULL);")
                    // table : friendship
                    .append("CREATE TABLE friendship (")
                    .append("friendship_id bigint unsigned NOT NULL primary key,")
                    .append("user_id bigint unsigned NOT NULL,")
                    .append("friend_id bigint unsigned NOT NULL,")
                    .append("starting_time varchar(15) NOT NULL,")
                    .append("ending_time varchar(15));").toString();

    public DatabaseHelper(Context context, String name, int version) {
        super(context, name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        System.out.println("**************************************");
        db.execSQL(CREATE_TABLE_SQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db
            , int oldVersion, int newVersion) {
        System.out.println("--------onUpdate Called--------"
                + oldVersion + "--->" + newVersion);
    }

}
