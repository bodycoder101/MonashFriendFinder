package edu.monash.monashfriendfinder.util;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import edu.monash.monashfriendfinder.pojo.C;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 06/05/2017
 * Time: 16:31
 * Place: SEU
 */


public class Search implements Runnable {
    private String keywords;
    private String searchUrl;
    private Handler handler;
    private int messageCode;

    public Search(String keywords, Handler handler, int messageCode) {
        this.keywords = keywords;
        searchUrl = C.GOOGLE_SEARCH_HOST + "?key=" + C.SEARCH_API_KEY + "&cx=" + C.CX + "&q=" + keywords;
        this.handler = handler;
        this.messageCode = messageCode;
    }

    @Override
    public void run() {

        Looper.prepare();

        Bundle bundle = new Bundle();
        OkHttpClient client = new OkHttpClient();

        // Create request for remote resource.
        Request request = new Request.Builder()
                .url(searchUrl)
                .build();

        // Execute the request and retrieve the response.
        Response response = null;
        try {
            response = client.newCall(request).execute();
            // Deserialize HTTP response to concrete type.
            JSONObject jsonObject = new JSONObject(response.body().string().toString());

            /**
             * TODO 进行冗余性的处理
             * 1. 如果不返回数据
             * 2. 返回的数据不符合格式
             */

            JSONObject queries = jsonObject.getJSONObject("queries");

            JSONArray searchRequest = queries.getJSONArray("request");
            JSONObject requestSearch = searchRequest.getJSONObject(0);
            bundle.putString("title", requestSearch.getString("title"));
            // identity.setTitle(temp.getString(0));
            // attribute: totalResults
            bundle.putString("totalResults", requestSearch.getString("totalResults"));
            // identity.setTotalResults(temp.getLong(2));
            // attribute: searchTerms
            bundle.putString("searchTerms", requestSearch.getString("searchTerms"));

            JSONArray items = jsonObject.getJSONArray("items");
            JSONObject itemsSearch = items.getJSONObject(0);
            JSONObject pagemap = itemsSearch.getJSONObject("pagemap");
            JSONArray movie = pagemap.getJSONArray("movie");
            JSONObject movieSearch = movie.getJSONObject(0);

            bundle.putString("name", movieSearch.getString("name"));
            bundle.putString("contentrating", movieSearch.getString("contentrating"));
            bundle.putString("duration", movieSearch.getString("duration"));
            bundle.putString("genre", movieSearch.getString("genre"));
            bundle.putString("datepublished", movieSearch.getString("datepublished"));
            bundle.putString("trailer", movieSearch.getString("trailer"));
            bundle.putString("description", movieSearch.getString("description"));
            bundle.putString("headline", movieSearch.getString("headline"));
            bundle.putString("provider", movieSearch.getString("provider"));
            bundle.putString("url", movieSearch.getString("url"));
            bundle.putString("awards", movieSearch.getString("awards"));
            bundle.putString("thumbnailurl", movieSearch.getString("thumbnailurl"));
            bundle.putString("keywords", movieSearch.getString("keywords"));

            // Image
            bundle.putString("image", movieSearch.getString("keywords"));
            URL movieImageUrl = new URL(movieSearch.getString("image"));
            HttpURLConnection httpURLConnection = (HttpURLConnection) movieImageUrl.openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setReadTimeout(50000);
            InputStream input = httpURLConnection.getInputStream();
            ByteArrayOutputStream outSteam = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len = -1;
            while ((len = input.read(buffer)) != -1) {
                outSteam.write(buffer, 0, len);
            }

            bundle.putByteArray("imageSource", outSteam.toByteArray());
            outSteam.close();
            input.close();
            Message message = new Message();
            message.what = messageCode;
            message.setData(bundle);
            handler.sendMessage(message);

        } catch (IOException e) {

            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Looper.loop();

    }
}
