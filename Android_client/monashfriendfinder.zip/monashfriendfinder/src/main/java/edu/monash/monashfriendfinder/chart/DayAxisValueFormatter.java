package edu.monash.monashfriendfinder.chart;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 11/05/2017
 * Time: 10:30
 * Place: SEU
 */


import com.github.mikephil.charting.charts.BarLineChartBase;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;

/**
 * Created by philipp on 02/06/16.
 */
public class DayAxisValueFormatter implements IAxisValueFormatter
{

    protected String[] locations;

    private BarLineChartBase<?> chart;

    public DayAxisValueFormatter(BarLineChartBase<?> chart, String[] locations) {
        this.chart = chart;
        this.locations = locations;
    }

    @Override
    public String getFormattedValue(float value, AxisBase axis) {

        return locations[(int) value - 1];
    }
}

