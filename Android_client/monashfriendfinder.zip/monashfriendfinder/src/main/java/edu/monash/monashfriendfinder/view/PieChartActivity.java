package edu.monash.monashfriendfinder.view;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 10/05/2017
 * Time: 23:27
 * Place: SEU
 */


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.TextView;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.interfaces.datasets.IDataSet;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.MPPointF;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

import edu.monash.monashfriendfinder.R;
import edu.monash.monashfriendfinder.chart.ChartBase;
import edu.monash.monashfriendfinder.pojo.C;

public class PieChartActivity extends ChartBase implements OnChartValueSelectedListener {
    private final String methodPath = "monashfriendfinder.profile/Profile.pieChart/";


    private PieChart mChart;
    // private SeekBar mSeekBarX, mSeekBarY;
    private TextView tvX, tvY;

    private Bundle bundle;

    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_piechart);

        // read data
        Intent intent = getIntent();
        bundle = intent.getBundleExtra("profile");
        final String studentName = bundle.getString("studentName");
        final String studentId = bundle.getString("studentId");

        // get the pie chart data
        PieThread pieThread = new PieThread(studentId);
        Thread thread = new Thread(pieThread);
        thread.start();

        handler = new android.os.Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                // Pie chart
                if (msg.what == 0x115) {
                    Bundle bundle = msg.getData();
                    String json = bundle.getString("pieData");
                    /*tvX = (TextView) findViewById(R.id.tvXMax);
                    tvY = (TextView) findViewById(R.id.tvYMax);*/

                    mChart = (PieChart) findViewById(R.id.chart1);
                    mChart.setUsePercentValues(true);
                    mChart.getDescription().setEnabled(false);
                    mChart.setExtraOffsets(5, 10, 5, 5);

                    mChart.setDragDecelerationFrictionCoef(0.95f);

                    // mChart.setDrawHoleEnabled(true);
                    // mChart.setHoleColor(Color.WHITE);

                    // mChart.setTransparentCircleColor(Color.WHITE);
                    // mChart.setTransparentCircleAlpha(110);

                    mChart.setHoleRadius(0);
                    mChart.setTransparentCircleRadius(0);

                    mChart.setDrawCenterText(true);

                    mChart.setRotationAngle(0);
                    // enable rotation of the chart by touch
                    mChart.setRotationEnabled(true);
                    mChart.setHighlightPerTapEnabled(true);

                    // mChart.setUnit(" €");
                    // mChart.setDrawUnitsInChart(true);

                    // add a selection listener
                    // mChart.setOnChartValueSelectedListener(this);

                    setData(json);

                    mChart.animateY(1400, Easing.EasingOption.EaseInOutQuad);
                    // mChart.spin(2000, 0, 360);

        /*mSeekBarX.setOnSeekBarChangeListener(this);
        mSeekBarY.setOnSeekBarChangeListener(this);*/

                    Legend l = mChart.getLegend();
                    l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
                    l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
                    l.setOrientation(Legend.LegendOrientation.VERTICAL);
                    l.setDrawInside(false);
                    l.setXEntrySpace(7f);
                    l.setYEntrySpace(0f);
                    l.setYOffset(0f);
                    // entry label styling
                    mChart.setEntryLabelColor(Color.BLACK);
                    mChart.setEntryLabelTypeface(mTfRegular);
                    mChart.setEntryLabelTextSize(15f);
                }
            }
        };
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent main = new Intent(PieChartActivity.this, ShowChartActivity.class);
        main.putExtra("profile", bundle);
        startActivity(main);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.pie, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.actionToggleValues: {
                for (IDataSet<?> set : mChart.getData().getDataSets())
                    set.setDrawValues(!set.isDrawValuesEnabled());

                mChart.invalidate();
                break;
            }
            case R.id.actionToggleIcons: {
                for (IDataSet<?> set : mChart.getData().getDataSets())
                    set.setDrawIcons(!set.isDrawIconsEnabled());

                mChart.invalidate();
                break;
            }
            case R.id.actionToggleHole: {
                if (mChart.isDrawHoleEnabled())
                    mChart.setDrawHoleEnabled(false);
                else
                    mChart.setDrawHoleEnabled(true);
                mChart.invalidate();
                break;
            }
            case R.id.actionDrawCenter: {
                if (mChart.isDrawCenterTextEnabled())
                    mChart.setDrawCenterText(false);
                else
                    mChart.setDrawCenterText(true);
                mChart.invalidate();
                break;
            }
            case R.id.actionToggleXVals: {

                mChart.setDrawEntryLabels(!mChart.isDrawEntryLabelsEnabled());
                mChart.invalidate();
                break;
            }
            case R.id.actionSave: {
                // mChart.saveToGallery("title"+System.currentTimeMillis());
                mChart.saveToPath("title" + System.currentTimeMillis(), "");
                break;
            }
            case R.id.actionTogglePercent:
                mChart.setUsePercentValues(!mChart.isUsePercentValuesEnabled());
                mChart.invalidate();
                break;
            case R.id.animateX: {
                mChart.animateX(1400);
                break;
            }
            case R.id.animateY: {
                mChart.animateY(1400);
                break;
            }
            case R.id.animateXY: {
                mChart.animateXY(1400, 1400);
                break;
            }
            case R.id.actionToggleSpin: {
                mChart.spin(1000, mChart.getRotationAngle(), mChart.getRotationAngle() + 360, Easing.EasingOption
                        .EaseInCubic);
                break;
            }
        }
        return true;
    }

    private void setData(String json) {
        JSONObject jsonObject = null;
        ArrayList<PieEntry> entries = new ArrayList<PieEntry>();
        try {
            jsonObject = new JSONObject(json);
            int records = Integer.parseInt(jsonObject.getString("records"));
            JSONArray data = jsonObject.getJSONArray("data");
            for (int i = 0; i < records; i++) {
                String course = data.getString(2 * i);
                String ratio = String.format(data.getString(2 * i + 1), "%.2f");
                entries.add(new PieEntry(Float.parseFloat(ratio),
                        course,
                        getResources().getDrawable(R.drawable.star)));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        PieDataSet dataSet = new PieDataSet(entries, "Favourite Units");

        dataSet.setDrawIcons(false);

        dataSet.setSliceSpace(3f);
        dataSet.setIconsOffset(new MPPointF(0, 40));
        dataSet.setSelectionShift(5f);

        // add a lot of colors

        ArrayList<Integer> colors = new ArrayList<Integer>();

        for (int c : ColorTemplate.VORDIPLOM_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.JOYFUL_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.COLORFUL_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.LIBERTY_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.PASTEL_COLORS)
            colors.add(c);

        colors.add(ColorTemplate.getHoloBlue());

        dataSet.setColors(colors);
        //dataSet.setSelectionShift(0f);

        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PercentFormatter());
        data.setValueTextSize(15f);
        data.setValueTextColor(Color.BLACK);
        data.setValueTypeface(mTfLight);
        mChart.setData(data);

        // undo all highlights
        mChart.highlightValues(null);

        mChart.invalidate();
    }

    @Override
    public void onValueSelected(Entry e, Highlight h) {

        if (e == null)
            return;
        Log.i("VAL SELECTED",
                "Value: " + e.getY() + ", index: " + h.getX()
                        + ", DataSet index: " + h.getDataSetIndex());
    }

    @Override
    public void onNothingSelected() {
        Log.i("PieChart", "nothing selected");
    }

    private class PieThread implements Runnable {
        private String studentId;

        public PieThread(String studentId) {
            this.studentId = studentId;
        }

        @Override
        public void run() {
            Looper.prepare();

            Bundle bundle = new Bundle();
            //Making HTTP request
            URL url = null;
            //open the connection
            HttpURLConnection conn = null;
            try {
                String searchUrl = C.SERVER_BASE_URI + methodPath + studentId + "/";
                //Making HTTP request
                url = new URL(searchUrl);
                //open the connection
                conn = (HttpURLConnection) url.openConnection();
                //set the timeout
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000); //set the connection method to GET
                conn.setRequestMethod("GET");
                //add http headers to set your response type to json
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json"); //Read the response
                Scanner inStream = new Scanner(conn.getInputStream()); //read the input steream and store it as string
                StringBuilder textResult = new StringBuilder();
                while (inStream.hasNextLine()) {
                    textResult.append(inStream.nextLine());
                }
                bundle.putString("pieData", textResult.toString());
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("Get pie chart data:", "failed.");
            } finally {
                conn.disconnect();
            }
            Message message = new Message();
            // Pie Chart
            message.what = 0x115;
            message.setData(bundle);
            handler.sendMessage(message);
            Looper.loop();
        }
    }
}

