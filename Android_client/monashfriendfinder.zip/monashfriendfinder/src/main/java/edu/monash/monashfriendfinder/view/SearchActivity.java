package edu.monash.monashfriendfinder.view;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import edu.monash.monashfriendfinder.R;
import edu.monash.monashfriendfinder.map.CustomMarkerActivity;
import edu.monash.monashfriendfinder.pojo.C;

/**
 * Created with Android Studio.
 * User: LiZhenzhen
 * Date: 10/05/2017
 */

public class SearchActivity extends AppCompatActivity {
    private final String methodPath = "monashfriendfinder.profile/Profile.findByAllAttributes?";

    private CheckBox cb_first_name;
    private CheckBox cb_sur_name;
    private CheckBox cb_dob;
    private CheckBox cb_gender;
    private CheckBox cb_address;
    private CheckBox cb_suburb;
    private CheckBox cb_nationality;
    private CheckBox cb_native_language;
    private CheckBox cb_favourite_movie;
    private CheckBox cb_favourite_unit;
    private CheckBox cb_favourite_sport;
    private CheckBox cb_study_model;
    private CheckBox cb_subscription_time;

    private ListView search_result_friend;

    private Button bt_show_in_map;

    private Bundle bundle;
    private Handler handler;

    List<String> showIdAndName = new ArrayList<String>(10);
    Map<String, String> data = new HashMap<String, String>(10);
    ArrayList<String> matchedStudentIds = new ArrayList<String>(10);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        Button search_button = (Button)findViewById(R.id.bt_search);
        cb_first_name = (CheckBox) findViewById(R.id.cb_first_name);
        cb_sur_name = (CheckBox) findViewById(R.id.cb_sur_name);
        cb_dob = (CheckBox) findViewById(R.id.cb_dob);
        cb_gender = (CheckBox) findViewById(R.id.cb_gender);
        cb_address = (CheckBox) findViewById(R.id.cb_address);
        cb_suburb = (CheckBox) findViewById(R.id.cb_suburb);
        cb_nationality = (CheckBox) findViewById(R.id.cb_nationality);
        cb_native_language = (CheckBox) findViewById(R.id.cb_native_language);
        cb_favourite_movie = (CheckBox) findViewById(R.id.cb_favourite_movie);
        cb_favourite_unit = (CheckBox) findViewById(R.id.cb_favourite_unit);
        cb_favourite_sport = (CheckBox) findViewById(R.id.cb_favourite_sport);
        cb_study_model = (CheckBox) findViewById(R.id.cb_study_model);
        cb_subscription_time = (CheckBox) findViewById(R.id.cb_subscription_time);

        search_result_friend = (ListView) findViewById(R.id.search_result_friend);

        bt_show_in_map = (Button) findViewById(R.id.bt_show_in_map);

        // read data
        Intent intent = getIntent();
        bundle = intent.getBundleExtra("profile");
        final String studentName = bundle.getString("studentName");
        final String studentId = bundle.getString("studentId");

        search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder stringBuilder = new StringBuilder("studentId=" + studentId);
                if (cb_first_name.isChecked()) {
                    stringBuilder.append("&attribute1=firstName");
                }
                if (cb_sur_name.isChecked()) {
                    stringBuilder.append("&attribute2=surName");
                }
                if (cb_dob.isChecked()) {
                    stringBuilder.append("&attribute3=doB");
                }
                if (cb_gender.isChecked()) {
                    stringBuilder.append("&attribute4=gender");
                }
                if (cb_address.isChecked()) {
                    stringBuilder.append("&attribute5=address");
                }
                if (cb_suburb.isChecked()) {
                    stringBuilder.append("&attribute6=suburb");
                }
                if (cb_nationality.isChecked()) {
                    stringBuilder.append("&attribute7=nationality");
                }
                if (cb_native_language.isChecked()) {
                    stringBuilder.append("&attribute8=nativeLanguage");
                }
                if (cb_favourite_movie.isChecked()) {
                    stringBuilder.append("&attribute9=favouriteMovie");
                }
                if (cb_favourite_unit.isChecked()) {
                    stringBuilder.append("&attribute10=favouriteUnit");
                }
                if (cb_favourite_sport.isChecked()) {
                    stringBuilder.append("&attribute11=favouriteSport");
                }
                if (cb_study_model.isChecked()) {
                    stringBuilder.append("&attribute12=studyMode");
                }
                if (cb_subscription_time.isChecked()) {
                    stringBuilder.append("&attribute13=cb_subscription_time");
                }
                // if a student do not select any matched attribute, do nothing
                if (stringBuilder.toString().endsWith("studentId")) {
                    Toast.makeText(SearchActivity.this,"You must select a matched attribute.",Toast.LENGTH_SHORT).show();
                } else {
                    MatchStudent matchStudent = new MatchStudent(stringBuilder.toString());
                    Thread thread = new Thread(matchStudent);
                    thread.start();
                }
            }
        });

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                // search matched student
                if (msg.what == 0x117) {
                    Bundle bundleResult = msg.getData();
                    String json = bundleResult.getString("matchedData");
                    try {
                        JSONArray jsonArray = new JSONArray(json);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            StringBuilder idAndName = new StringBuilder("ID: ");
                            JSONObject person = jsonArray.getJSONObject(i);
                            String studentId = person.getString("studentId");
                            // save the student Ids for the use of showing on map
                            matchedStudentIds.add(studentId);

                            idAndName.append(studentId).append(";");
                            String firstName = person.getString("firstName");
                            idAndName.append(" Name: ").append(firstName);
                            String surName = person.getString("surName");
                            idAndName.append(" ").append(surName).append(".");

                            showIdAndName.add(idAndName.toString());
                            data.put(studentId, person.toString());

                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(SearchActivity.this, android.R.layout.simple_spinner_item, showIdAndName);
                        search_result_friend.setAdapter(adapter);
                        search_result_friend.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                String ID = showIdAndName.get(position).split(";")[0].substring(3).trim();
                                Bundle matchedDetailBundle  = new Bundle();
                                matchedDetailBundle.putString("StudentDetail", data.get(ID));
                                matchedDetailBundle.putString("SelfId", studentId);
                                Intent matchedDetailIntent = new Intent(SearchActivity.this, MatchedStudent.class);
                                matchedDetailIntent.putExtra("matchedDetail", matchedDetailBundle);
                                matchedDetailIntent.putExtra("profile", bundle);
                                startActivity(matchedDetailIntent);
                            }
                        });
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    bt_show_in_map.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Bundle showInMapBundle = new Bundle();
                            Intent showInMapIntent = new Intent(SearchActivity.this, CustomMarkerActivity.class);
                            showInMapBundle.putStringArrayList("studentIds", matchedStudentIds);
                            showInMapIntent.putExtra("ShowInMap", showInMapBundle);
                            showInMapIntent.putExtra("profile", bundle);
                            startActivity(showInMapIntent);
                        }
                    });
                }
            }
        };
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent main = new Intent(SearchActivity.this, MainActivity.class);
        main.putExtra("profile", bundle);
        startActivity(main);
        finish();
    }

    private class MatchStudent implements Runnable {
        private String parameters;

        public MatchStudent(String parameters) {
            this.parameters =  parameters;
        }

        @Override
        public void run() {
            Looper.prepare();

            Bundle bundle = new Bundle();
            //Making HTTP request
            URL url = null;
            //open the connection
            HttpURLConnection conn = null;
            try {
                String searchUrl = C.SERVER_BASE_URI + methodPath + parameters;
                //Making HTTP request
                url = new URL(searchUrl);
                //open the connection
                conn = (HttpURLConnection) url.openConnection();
                //set the timeout
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000); //set the connection method to GET
                conn.setRequestMethod("GET");
                //add http headers to set your response type to json
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json"); //Read the response
                Scanner inStream = new Scanner(conn.getInputStream()); //read the input steream and store it as string
                StringBuilder textResult = new StringBuilder();
                while (inStream.hasNextLine()) {
                    textResult.append(inStream.nextLine());
                }
                bundle.putString("matchedData", textResult.toString());
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("Get matched students:", "failed.");
            } finally {
                conn.disconnect();
            }
            Message message = new Message();
            // search matched students
            message.what = 0x117;
            message.setData(bundle);
            handler.sendMessage(message);
            Looper.loop();
        }
    }
}
