package edu.monash.monashfriendfinder.util;

import android.Manifest;
import android.content.pm.PackageManager;

import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 02/05/2017
 * Time: 18:05
 * Place: SEU
 */


public class Location {
    /**
     * 需要进行检测的权限数组
     */
    protected String[] needPermissions = {
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.READ_PHONE_STATE
    };

    private AMapLocationClient locationClient = null;
    private AMapLocationClientOption locationOption = null;
    private static final int PERMISSON_REQUESTCODE = 0;

//    private void checkPermissions(String... permissions) {
//        List<String> needRequestPermissonList = findDeniedPermissions(permissions);
//        if (null != needRequestPermissonList
//                && needRequestPermissonList.size() > 0) {
//            ActivityCompat.requestPermissions(this,
//                    needRequestPermissonList.toArray(
//                            new String[needRequestPermissonList.size()]),
//                    PERMISSON_REQUESTCODE);
//        }
//    }

    /**
     * 初始化定位
     *
     * @since 2.8.0
     * @author hongming.wang
     *
     */
//    private void initLocation(){
//        //初始化client
//        locationClient = new AMapLocationClient(this.getApplicationContext());
//        locationOption = getDefaultOption();
//        //设置定位参数
//        locationClient.setLocationOption(locationOption);
//        // 设置定位监听
//        locationClient.setLocationListener(locationListener);
//    }


    /**
     * 获取权限集中需要申请权限的列表
     *
     * @param permissions
     * @return
     * @since 2.5.0
     *
     */
//    private List<String> findDeniedPermissions(String[] permissions) {
//        List<String> needRequestPermissonList = new ArrayList<String>();
//        for (String perm : permissions) {
//            if (ContextCompat.checkSelfPermission(this,
//                    perm) != PackageManager.PERMISSION_GRANTED
//                    || ActivityCompat.shouldShowRequestPermissionRationale(
//                    this, perm)) {
//                needRequestPermissonList.add(perm);
//            }
//        }
//        return needRequestPermissonList;
//    }

    /**
     * 检测是否说有的权限都已经授权
     * @param grantResults
     * @return
     * @since 2.5.0
     *
     */
    private boolean verifyPermissions(int[] grantResults) {
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }
}
