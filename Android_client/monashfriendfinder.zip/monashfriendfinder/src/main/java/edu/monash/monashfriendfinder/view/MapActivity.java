package edu.monash.monashfriendfinder.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import edu.monash.monashfriendfinder.R;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 06/05/2017
 * Time: 13:18
 * Place: SEU
 */

public class MapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
    }
}
