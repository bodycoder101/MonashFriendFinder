package edu.monash.monashfriendfinder.view;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import edu.monash.monashfriendfinder.R;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 11/05/2017
 * Time: 15:25
 * Place: SEU
 */


public class ShowChartActivity extends Activity {

    private TextView tv_pie;
    private TextView tv_bar;
    private Bundle bundle;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_chart);

        tv_bar = (TextView) findViewById(R.id.tv_bar);
        tv_pie = (TextView) findViewById(R.id.tv_pie);

        // read data
        Intent intent = getIntent();
        bundle = intent.getBundleExtra("profile");
        final String studentName = bundle.getString("studentName");
        final String studentId = bundle.getString("studentId");

        tv_bar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent barIntent = new Intent(ShowChartActivity.this, SelectLocationBarActivity.class);
                barIntent.putExtra("profile", bundle);
                startActivity(barIntent);
                finish();
            }
        });

        tv_pie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pieIntent = new Intent(ShowChartActivity.this, PieChartActivity.class);
                pieIntent.putExtra("profile", bundle);
                startActivity(pieIntent);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent main = new Intent(ShowChartActivity.this, MainActivity.class);
        main.putExtra("profile", bundle);
        startActivity(main);
        this.finish();
    }

}
