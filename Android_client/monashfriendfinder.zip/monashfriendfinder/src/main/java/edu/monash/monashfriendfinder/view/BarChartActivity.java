package edu.monash.monashfriendfinder.view;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 11/05/2017
 * Time: 10:29
 * Place: SEU
 */


import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.Legend.LegendForm;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.XAxis.XAxisPosition;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.components.YAxis.YAxisLabelPosition;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.interfaces.datasets.IDataSet;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.MPPointF;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

import edu.monash.monashfriendfinder.R;
import edu.monash.monashfriendfinder.chart.ChartBase;
import edu.monash.monashfriendfinder.chart.DayAxisValueFormatter;
import edu.monash.monashfriendfinder.chart.MyAxisValueFormatter;
import edu.monash.monashfriendfinder.chart.XYMarkerView;
import edu.monash.monashfriendfinder.pojo.C;

public class BarChartActivity extends ChartBase implements OnChartValueSelectedListener {
    private final String methodPath = "monashfriendfinder.location/Location.locationFrequencies/";

    protected BarChart mChart;
    // private SeekBar mSeekBarX, mSeekBarY;
    // private TextView tvX, tvY;

    private Bundle bundle;

    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_barchart);

        // read data
        Intent intent = getIntent();
        bundle = intent.getBundleExtra("profile");
        final String studentName = bundle.getString("studentName");
        final String studentId = bundle.getString("studentId");
        final String startDate = bundle.getString("startDate");
        final String endDate = bundle.getString("endDate");
        bundle.remove("startDate");
        bundle.remove("endDate");

        BarThread barThread = new BarThread(studentId, startDate, endDate);
        Thread thread = new Thread(barThread);
        thread.start();

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                // Pie chart
                if (msg.what == 0x116) {
                    Bundle bundle = msg.getData();
                    String json = bundle.getString("barData");
                    // parse data for the use of xAxis
                    JSONObject jsonObject = null;
                    String[] locations = null;
                    try {
                        jsonObject = new JSONObject(json);
                        int records = Integer.parseInt(jsonObject.getString("records"));
                        // init the locations string array
                        locations = new String[records];
                        JSONArray dataJson = jsonObject.getJSONArray("data");
                        for (int i = 0; i < records; i++) {
                            String locationName = dataJson.getString(2 * i);
                            locations[i] = locationName;
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    mChart = (BarChart) findViewById(R.id.chart1);
                    mChart.setOnChartValueSelectedListener(BarChartActivity.this);

                    mChart.setDrawBarShadow(false);
                    mChart.setDrawValueAboveBar(true);

                    mChart.getDescription().setEnabled(false);

                    // if more than 60 entries are displayed in the chart, no values will be
                    // drawn
                    mChart.setMaxVisibleValueCount(60);

                    // scaling can now only be done on x- and y-axis separately
                    mChart.setPinchZoom(false);

                    mChart.setDrawGridBackground(false);
                    // mChart.setDrawYLabels(false);

                    if (locations == null) {
                        locations = new String[]{"NONE"};
                    }

                    IAxisValueFormatter xAxisFormatter = new DayAxisValueFormatter(mChart, locations);

                    XAxis xAxis = mChart.getXAxis();
                    xAxis.setPosition(XAxisPosition.BOTTOM);
                    xAxis.setTypeface(mTfLight);
                    xAxis.setDrawGridLines(false);
                    xAxis.setGranularity(1f); // only intervals of 1 day
                    xAxis.setLabelCount(7);
                    xAxis.setValueFormatter(xAxisFormatter);

                    IAxisValueFormatter custom = new MyAxisValueFormatter();

                    YAxis leftAxis = mChart.getAxisLeft();
                    leftAxis.setTypeface(mTfLight);
                    leftAxis.setLabelCount(8, false);
                    leftAxis.setValueFormatter(custom);
                    leftAxis.setPosition(YAxisLabelPosition.OUTSIDE_CHART);
                    leftAxis.setSpaceTop(15f);
                    leftAxis.setAxisMinimum(0f); // this replaces setStartAtZero(true)

                    YAxis rightAxis = mChart.getAxisRight();
                    rightAxis.setDrawGridLines(false);
                    rightAxis.setTypeface(mTfLight);
                    rightAxis.setLabelCount(8, false);
                    rightAxis.setValueFormatter(custom);
                    rightAxis.setSpaceTop(15f);
                    rightAxis.setAxisMinimum(0f); // this replaces setStartAtZero(true)

                    Legend l = mChart.getLegend();
                    l.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
                    l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
                    l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
                    l.setDrawInside(false);
                    l.setForm(LegendForm.SQUARE);
                    l.setFormSize(9f);
                    l.setTextSize(11f);
                    l.setXEntrySpace(4f);
                    // l.setExtra(ColorTemplate.VORDIPLOM_COLORS, new String[] { "abc",
                    // "def", "ghj", "ikl", "mno" });
                    // l.setCustom(ColorTemplate.VORDIPLOM_COLORS, new String[] { "abc",
                    // "def", "ghj", "ikl", "mno" });

                    XYMarkerView mv = new XYMarkerView(BarChartActivity.this, xAxisFormatter);
                    mv.setChartView(mChart); // For bounds control
                    mChart.setMarker(mv); // Set the marker to the chart

                    setData(json);
                    // refresh
                    mChart.invalidate();

                }
            }
        };


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent main = new Intent(BarChartActivity.this, ShowChartActivity.class);
        main.putExtra("profile", bundle);
        startActivity(main);
        finish();
    }



    private void setData(String json) {
        JSONObject jsonObject = null;
        ArrayList<BarEntry> yVals1 = new ArrayList<BarEntry>();
        try {
            jsonObject = new JSONObject(json);
            int records = Integer.parseInt(jsonObject.getString("records"));
            JSONArray data = jsonObject.getJSONArray("data");
            for (int i = 0; i < records; i++) {
                String frequencies = data.getString(2 * i + 1);
                yVals1.add(new BarEntry(i + 1, Float.parseFloat(frequencies)));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        BarDataSet set1;

        if (mChart.getData() != null &&
                mChart.getData().getDataSetCount() > 0) {
            set1 = (BarDataSet) mChart.getData().getDataSetByIndex(0);
            set1.setValues(yVals1);
            mChart.getData().notifyDataChanged();
            mChart.notifyDataSetChanged();
        } else {
            set1 = new BarDataSet(yVals1, "Places and its frequencies");

            set1.setDrawIcons(false);

            set1.setColors(ColorTemplate.MATERIAL_COLORS);

            ArrayList<IBarDataSet> dataSets = new ArrayList<IBarDataSet>();
            dataSets.add(set1);

            BarData data = new BarData(dataSets);
            data.setValueTextSize(10f);
            data.setValueTypeface(mTfLight);
            data.setBarWidth(0.9f);

            mChart.setData(data);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.bar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.actionToggleValues: {
                for (IDataSet set : mChart.getData().getDataSets())
                    set.setDrawValues(!set.isDrawValuesEnabled());

                mChart.invalidate();
                break;
            }
            case R.id.actionToggleIcons: {
                for (IDataSet set : mChart.getData().getDataSets())
                    set.setDrawIcons(!set.isDrawIconsEnabled());

                mChart.invalidate();
                break;
            }
            case R.id.actionToggleHighlight: {
                if (mChart.getData() != null) {
                    mChart.getData().setHighlightEnabled(!mChart.getData().isHighlightEnabled());
                    mChart.invalidate();
                }
                break;
            }
            case R.id.actionTogglePinch: {
                if (mChart.isPinchZoomEnabled())
                    mChart.setPinchZoom(false);
                else
                    mChart.setPinchZoom(true);

                mChart.invalidate();
                break;
            }
            case R.id.actionToggleAutoScaleMinMax: {
                mChart.setAutoScaleMinMaxEnabled(!mChart.isAutoScaleMinMaxEnabled());
                mChart.notifyDataSetChanged();
                break;
            }
            case R.id.actionToggleBarBorders: {
                for (IBarDataSet set : mChart.getData().getDataSets())
                    ((BarDataSet) set).setBarBorderWidth(set.getBarBorderWidth() == 1.f ? 0.f : 1.f);

                mChart.invalidate();
                break;
            }
            case R.id.animateX: {
                mChart.animateX(3000);
                break;
            }
            case R.id.animateY: {
                mChart.animateY(3000);
                break;
            }
            case R.id.animateXY: {

                mChart.animateXY(3000, 3000);
                break;
            }
            case R.id.actionSave: {
                if (mChart.saveToGallery("title" + System.currentTimeMillis(), 50)) {
                    Toast.makeText(getApplicationContext(), "Saving SUCCESSFUL!",
                            Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(getApplicationContext(), "Saving FAILED!", Toast.LENGTH_SHORT)
                            .show();
                break;
            }
        }
        return true;
    }



    protected RectF mOnValueSelectedRectF = new RectF();

    @SuppressLint("NewApi")
    @Override
    public void onValueSelected(Entry e, Highlight h) {

        if (e == null)
            return;

        RectF bounds = mOnValueSelectedRectF;
        mChart.getBarBounds((BarEntry) e, bounds);
        MPPointF position = mChart.getPosition(e, YAxis.AxisDependency.LEFT);

        Log.i("bounds", bounds.toString());
        Log.i("position", position.toString());

        Log.i("x-index",
                "low: " + mChart.getLowestVisibleX() + ", high: "
                        + mChart.getHighestVisibleX());

        MPPointF.recycleInstance(position);
    }

    @Override
    public void onNothingSelected() { }

    private class BarThread implements Runnable {
        private String studentId;
        private String startDate;
        private String endDate;

        public BarThread(String studentId, String startDate, String endDate) {
            this.studentId = studentId;
            this.startDate = startDate;
            this.endDate = endDate;
        }

        @Override
        public void run() {
            Looper.prepare();

            Bundle bundle = new Bundle();
            //Making HTTP request
            URL url = null;
            //open the connection
            HttpURLConnection conn = null;
            try {
                String searchUrl = C.SERVER_BASE_URI + methodPath + studentId + "/" + startDate + "/" + endDate + "/";
                //Making HTTP request
                url = new URL(searchUrl);
                //open the connection
                conn = (HttpURLConnection) url.openConnection();
                //set the timeout
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000); //set the connection method to GET
                conn.setRequestMethod("GET");
                //add http headers to set your response type to json
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json"); //Read the response
                Scanner inStream = new Scanner(conn.getInputStream()); //read the input steream and store it as string
                StringBuilder textResult = new StringBuilder();
                while (inStream.hasNextLine()) {
                    textResult.append(inStream.nextLine());
                }
                bundle.putString("barData", textResult.toString());
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("Get bar chart data:", "failed.");
            } finally {
                conn.disconnect();
            }
            Message message = new Message();
            // bar date
            message.what = 0x116;
            message.setData(bundle);
            handler.sendMessage(message);
            Looper.loop();
        }
    }
}
