package edu.monash.monashfriendfinder.view;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

import edu.monash.monashfriendfinder.R;
import edu.monash.monashfriendfinder.pojo.C;
import edu.monash.monashfriendfinder.util.ToastUtil;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 06/05/2017
 * Time: 16:31
 * Place: SEU
 */

public class DeleteFriendActivity extends AppCompatActivity {
    private final String methodPath = "monashfriendfinder.friendship/Friendship.deleteFriendships/";

    private Bundle bundle;
    private Handler handler;

    private TextView te_student_id;
    private TextView te_firstName;
    private TextView te_surName;
    private TextView te_doB;
    private TextView te_gender;
    private TextView te_startingTime;

    private Button btn_delete;

    private Bundle profileBundle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_friend);

        te_student_id = (TextView) findViewById(R.id.te_student_id);
        te_firstName = (TextView) findViewById(R.id.te_firstName);
        te_surName = (TextView) findViewById(R.id.te_surName);
        te_doB = (TextView) findViewById(R.id.te_doB);
        te_gender = (TextView) findViewById(R.id.te_gender);
        te_startingTime = (TextView) findViewById(R.id.te_startingTime);
        btn_delete = (Button) findViewById(R.id.btn_delete);

        // read data
        Intent intent = getIntent();

        bundle = intent.getBundleExtra("FriendDetailBundle");
        profileBundle = intent.getBundleExtra("profile");
        final String selfId = bundle.getString("SelfId");
        String json = bundle.getString("FriendDetail");

        try {
            JSONObject frienship = new JSONObject(json);
            JSONObject friendId = frienship.getJSONObject("friendId");

            te_doB.setText(friendId.getString("doB").split("T")[0]);
            te_firstName.setText(friendId.getString("firstName"));
            te_gender.setText(friendId.getString("gender"));
            te_student_id.setText(friendId.getString("studentId"));
            te_surName.setText(friendId.getString("surName"));
            te_startingTime.setText(frienship.getString("startingTime").split("T")[0]);;

        } catch (JSONException e) {
            e.printStackTrace();
        }

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String studentId = te_student_id.getText().toString();
                DeleteFriendship deleteFriendship = new DeleteFriendship(selfId, studentId);
                Thread thread = new Thread(deleteFriendship);
                thread.start();
            }
        });

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (msg.what == 0x120) {
                    Bundle bundle = msg.getData();
                    String result = bundle.getString("result");
                    if ("true".equals(result)) {
                        ToastUtil.show(getApplicationContext(), "Delete friend succeed.");
                        Intent searchIntent = new Intent(DeleteFriendActivity.this, FriendListActivity.class);
                        searchIntent.putExtra("profile", profileBundle);
                        startActivity(searchIntent);
                        finish();
                    } else {
                        ToastUtil.show(getApplicationContext(), "Delete friend failed.");
                    }
                }
            }
        };

    }

    private class DeleteFriendship implements Runnable {
        private String selfId;
        private String studentId;

        public DeleteFriendship(String selfId, String studentId) {
            this.selfId = selfId;
            this.studentId = studentId;
        }

        @Override
        public void run() {
            Looper.prepare();

            Bundle bundle = new Bundle();
            //Making HTTP request
            URL url = null;
            //open the connection
            HttpURLConnection conn = null;
            try {
                String searchUrl = C.SERVER_BASE_URI + methodPath + selfId + "/" + studentId + "/";
                //Making HTTP request
                url = new URL(searchUrl);
                //open the connection
                conn = (HttpURLConnection) url.openConnection();
                //set the timeout
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000); //set the connection method to GET
                conn.setRequestMethod("DELETE");
                //add http headers to set your response type to json
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json"); //Read the response
                Scanner inStream = new Scanner(conn.getInputStream()); //read the input steream and store it as string
                StringBuilder textResult = new StringBuilder();
                while (inStream.hasNextLine()) {
                    textResult.append(inStream.nextLine());
                }
                if ("true".equals(textResult.toString())) {
                    bundle.putString("result", "true");
                } else {
                    bundle.putString("result", "false");
                }
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("Delete friendship:", "failed.");
            } finally {
                conn.disconnect();
            }
            Message message = new Message();
            // delete friendship
            message.what = 0x120;
            message.setData(bundle);
            handler.sendMessage(message);
            Looper.loop();
        }
    }
}
