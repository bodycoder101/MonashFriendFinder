package edu.monash.monashfriendfinder.view;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import edu.monash.monashfriendfinder.R;
import edu.monash.monashfriendfinder.map.CustomMarkerActivity;
import edu.monash.monashfriendfinder.pojo.C;

/**
 * Created with Android Studio.
 * User: lotus
 * Date: 07/05/2017
 * Time: 16:20
 * Place: SEU
 */

public class FriendListActivity extends AppCompatActivity {
    private final String methodPath = "monashfriendfinder.friendship/Friendship.findByUserId/";

    private ListView friends;

    private Bundle bundle;
    private Handler handler;
    private Button bt_show_in_map_friendship;

    List<String> showIdAndName = new ArrayList<String>(10);
    Map<String, String> data = new HashMap<String, String>(10);
    ArrayList<String> matchedStudentIds = new ArrayList<String>(10);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_list);

        friends = (ListView) findViewById(R.id.friends);

        bt_show_in_map_friendship = (Button)findViewById(R.id.bt_show_in_map_friendship);
        // read data
        Intent intent = getIntent();
        bundle = intent.getBundleExtra("profile");
        final String studentName = bundle.getString("studentName");
        final String studentId = bundle.getString("studentId");

        SearchFriend searchFriend = new SearchFriend(studentId);
        Thread thread = new Thread(searchFriend);
        thread.start();

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                // search friends list
                if (msg.what == 0x119) {
                    Bundle bundleResult = msg.getData();
                    String json = bundleResult.getString("FriendsList");
                    try {
                        JSONArray jsonArray = new JSONArray(json);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject friendship = jsonArray.getJSONObject(i);
                            JSONObject friend = friendship.getJSONObject("friendId");
                            StringBuilder idAndName = new StringBuilder("ID: ");
                            String id = friend.getString("studentId");
                            matchedStudentIds.add(id);

                            idAndName.append(id).append("; Name: ");
                            idAndName.append(friend.getString("firstName")).append(" ").append(friend.getString("surName"));

                            showIdAndName.add(idAndName.toString());
                            data.put(id, friendship.toString());

                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(FriendListActivity.this, android.R.layout.simple_spinner_item, showIdAndName);
                        friends.setAdapter(adapter);
                        friends.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                String ID = showIdAndName.get(position).split(";")[0].substring(3).trim();
                                Bundle friendDetailBundle  = new Bundle();
                                friendDetailBundle.putString("FriendDetail", data.get(ID));
                                friendDetailBundle.putString("SelfId", studentId);
                                Intent friendDetailIntent = new Intent(FriendListActivity.this, DeleteFriendActivity.class);
                                friendDetailIntent.putExtra("FriendDetailBundle", friendDetailBundle);
                                friendDetailIntent.putExtra("profile", bundle);
                                startActivity(friendDetailIntent);
                                finish();
                            }
                        });
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        bt_show_in_map_friendship.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle showInMapBundle = new Bundle();
                Intent showInMapIntent = new Intent(FriendListActivity.this, CustomMarkerActivity.class);
                showInMapBundle.putStringArrayList("studentIds", matchedStudentIds);
                showInMapIntent.putExtra("ShowInMap", showInMapBundle);
                showInMapIntent.putExtra("profile", bundle);
                startActivity(showInMapIntent);
            }
        });
    }

    private class SearchFriend implements Runnable {
        private String selfId;

        public SearchFriend(String selfId) {
            this.selfId = selfId;
        }

        @Override
        public void run() {
            Looper.prepare();

            Bundle bundle = new Bundle();
            //Making HTTP request
            URL url = null;
            //open the connection
            HttpURLConnection conn = null;
            try {
                String searchUrl = C.SERVER_BASE_URI + methodPath + selfId + "/";
                //Making HTTP request
                url = new URL(searchUrl);
                //open the connection
                conn = (HttpURLConnection) url.openConnection();
                //set the timeout
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000); //set the connection method to GET
                conn.setRequestMethod("GET");
                //add http headers to set your response type to json
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json"); //Read the response
                Scanner inStream = new Scanner(conn.getInputStream()); //read the input steream and store it as string
                StringBuilder textResult = new StringBuilder();
                while (inStream.hasNextLine()) {
                    textResult.append(inStream.nextLine());
                }
                bundle.putString("FriendsList", textResult.toString());
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("Get Friends List:", "failed.");
            } finally {
                conn.disconnect();
            }
            Message message = new Message();
            // search friends list
            message.what = 0x119;
            message.setData(bundle);
            handler.sendMessage(message);
            Looper.loop();
        }
    }
}
